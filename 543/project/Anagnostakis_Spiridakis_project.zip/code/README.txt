﻿README
Emmanouil Anagnostakis
Konstadinos Spiridakis
Submit contains 2 folders .
Local , contains files(code) ran on local machines with small input in order to perform manual grid search and find which model fits better to our problem.
Each model regression and classification are being constructed in different functions named properly.
Cluster, contains  files (code) of the three best predictions models.

