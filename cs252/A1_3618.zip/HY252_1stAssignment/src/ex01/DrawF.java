package ex01;
import java.util.Scanner;

public class DrawF {
	public static void main(String args[])
	{
		Scanner obj = new Scanner(System.in);
		int L;
		System.out.print("Enter a number of lines for F: ");
		L = obj.nextInt();
		
		while (L >= 4 && L <= 30)
		{
		for (int i = 1; i <= L; i++)
		{
			if (i == 1 && L <= 5)
			{
				System.out.println("*******");
			}
			else if (i == 1 && L > 5)
			{
				System.out.println("*******");
			}
			else if (i == 3 && L <= 5)
			{
				System.out.println("*****");
			}
			else if (i == L/2 && L > 5)
			{
				System.out.println("*****");
			}
			else 
			{
				System.out.println("*");
			}
		}
		System.out.println("F is done, enter new number: ");
		L = obj.nextInt();
		}
		if (L < 4 || L > 30)
		{
			System.out.println("Your number of lines must be between or equal to 4 and 30!!!");
		}
	}

}
