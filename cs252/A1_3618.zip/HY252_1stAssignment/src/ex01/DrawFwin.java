package ex01;
import javax.swing.JOptionPane;
 
public class DrawFwin {
	public static void main(String args[])
	{
		int L = 0;
		int inputk = Integer.parseInt(JOptionPane.showInputDialog("Enter a number of lines for F: ", L));

		while (inputk >= 4 && inputk <= 30)
		{
			String s = "";
			String A[] = new String[inputk];
			for (int i = 0; i < A.length; i++)
			{
				if (i == 0 && A.length <= 5)
				{
					A[i] = ("*******");
				}
				else if (i == 0 && A.length > 5)
				{
					A[i] = ("*******");
				}
				else if (i == 2 && A.length <= 5)
				{
					A[i] = ("*****");
				}
				else if (i == A.length/2 && A.length > 5)
				{
					A[i] = ("*****");
				}
				else 
				{
					A[i] = ("*");
				}
			}
			
			for (int i = 0; i < inputk; i++)
			{
				s = s +A[i] +"\n";
			}
			JOptionPane.showMessageDialog(null, s, "F with *: ", JOptionPane.INFORMATION_MESSAGE);

	    inputk = Integer.parseInt(JOptionPane.showInputDialog("Enter a number of lines for F: ", L));
		}
		if (inputk < 4 || inputk > 30)
		{
			JOptionPane.showMessageDialog(null, "Your number of lines must be between or equal to 4 and 30!!!", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
		
	}

}


