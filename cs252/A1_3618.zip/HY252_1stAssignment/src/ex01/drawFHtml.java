package ex01;
import java.util.*; 
import java.io.*;

public class drawFHtml {
	public static void main(String args[])
	{
		Scanner sc = new Scanner (System.in);
		
		File fhtml = new File("PhiF.html");
		try
		{
			System.out.print("Enter number for K: ");
			int K = sc.nextInt();
			if (K >= 4 && K<=30)
		    {
				BufferedWriter bfw = new BufferedWriter (new FileWriter(fhtml)); 
				bfw.write("<!DOCTYPE html>\n<html>\n<head>\n<meta http-equiv=\"content-type content=\"text/html;charset=utf-8\" />\n</head\n<body>\n\n<p style=\"font-size:"+K*10+"%*\" align=\"center\">F</p>\n\n</body>\n</html>");
				bfw.close();
		    }
		
			else
			{
				System.out.println("Your number of lines must be between or equal to 4 and 30!!!");
		    }
		}
		catch (Exception e)
		{
			System.out.println("error");
		}
	}
}