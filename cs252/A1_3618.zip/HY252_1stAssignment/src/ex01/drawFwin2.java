package ex01;
import javax.swing.JOptionPane;

public class drawFwin2 {
		public static void main(String args[])
		{
			int L = 0;
			int inputk = Integer.parseInt(JOptionPane.showInputDialog("Enter a number of lines for F: ", L));

			while (inputk >= 4 && inputk <= 30)
			{
				int A[] = new int[inputk+13];
				for (int i = 0; i < A.length; i++)
				{
					if (i >= 0 && i <= 9 ) 
					{
						A[i] = 1;
					}
					else if (i >= 11 && i <= 15) 
					{
						A[i] = 3;
					}
					else
					{
						A[10] = 2;
						A[i] = i-12;
					}
				}
				
				String s[] = new String[inputk];
				
				s[0] = Integer.toString(A[0]) +Integer.toString(A[1]) +Integer.toString(A[2]) +Integer.toString(A[3]) +Integer.toString(A[4])+Integer.toString(A[5]) +Integer.toString(A[6])+Integer.toString(A[7]) +Integer.toString(A[8]) +Integer.toString(A[9])+"\n";
				s[1] = Integer.toString(A[10]) +"\n";
				s[2] = Integer.toString(A[11]) +Integer.toString(A[12]) +Integer.toString(A[13])+Integer.toString(A[14]) +Integer.toString(A[15])+"\n";
				
				for (int i = 3; i < inputk; i++)
				{
					s[i] = Integer.toString(A[i+13]) +"\n"; 
				}
				
			    JOptionPane.showMessageDialog(null, s, "F with integers: ", JOptionPane.INFORMATION_MESSAGE);
			
		        inputk = Integer.parseInt(JOptionPane.showInputDialog("Enter a number of lines for F: ", L));
			}
			if (inputk < 4 || inputk > 30)
			{
				JOptionPane.showMessageDialog(null, "Your number of lines must be between or equal to 4 and 30!!!", "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			
		}

	}