package ex02;
import javax.swing.JOptionPane;
import org.jfugue.Player;

public class PingPong {
	
	public static class Ping {
		public static void main(String args[])
		{
			int n = 0;
			int  k = Integer.parseInt(JOptionPane.showInputDialog("Give me a number: ",n));
			Utilities obj1 = new Utilities();
			ping(k);
			obj1.sound(k);
			if (k > 1)
			{
				pong(k-1);
			}
		}


	static void ping(int k) 
	{
		JOptionPane.showMessageDialog(null, k , "Ping", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static class Pong {
		public static void main(String args[])
		{
			int n = 0;
			int  k = Integer.parseInt(JOptionPane.showInputDialog("Give me a number: ",n));
			Utilities obj2 = new Utilities();
			pong(k);
			obj2.sound(k);
			if (k > 1)
			{
				ping(k-1);
			}
		}
	}


	static void pong(int k) 
	{
		JOptionPane.showMessageDialog(null, k , "Pong", JOptionPane.INFORMATION_MESSAGE);
	}
}
	public static class Utilities
	{
		static void sound(int k)
		{
			String s;
			int x = k * 12;
			s = "[" + x + "]";
			Player p = new Player();
			p.play(s);

		}
	}
}






