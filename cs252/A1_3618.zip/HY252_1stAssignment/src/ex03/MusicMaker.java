package ex03;
import java.util.Scanner;
import org.jfugue.Player;

public class MusicMaker {
	
	static int[] concat(int a[], int b[]) 
	{
		int[] c = new int[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
	}

	static int[] expandHappy(int input[])
	{
		int A[] = new int[3];
		for (int i = 0; i < 3; i++)
		{
			if (i == 1)
			{
			A[i] = input[i] + 4;
			}
			else if(i == 2)
			{
				A[i] = input[i] + 7;
			}
			else
			{
				A[i] = input[i];
			}
			
		}
		return A;
	}
	
	static int[] expandSad(int[] input)
	{
		int A[] = new int[3];
		for (int i = 0; i < 3; i++)
		{
			if (i == 1)
			{
			A[i] = input[i] + 3;
			}
			else if(i == 2)
			{
				A[i] = input[i] + 7;
			}
			else
			{
				A[i] = input[i];
			}
			
		}
		return A;
	}
	
	
	static void playArray(int a[]) 
	{
		String s;
		for (int i = 0; i < a.length; i++)
		{
			s = "[" +a[i] +"]";
			System.out.print(s);
			Player p = new Player();
			p.play(s);
		}
	}
	
	
	public static void main(String[] args)
	{
		
		int a[] = new int[3];
		Scanner obj1 = new Scanner(System.in);
		System.out.println("Enter numbers one by one for array a:");
		for (int i = 0; i < 3; i++)
		{
			a[i] = obj1.nextInt();
		}
		
	
		int b[] = new int[3];
		Scanner obj2 = new Scanner(System.in);
		System.out.println("Enter numbers one by one for array b:");
		for (int i = 0; i < 3; i++)
		{
			b[i] = obj2.nextInt();
		}
		int ab[] = new int[a.length + b.length];
		ab = concat(a,b);
		for (int i = 0; i < ab.length; i++)
		{
			System.out.print("["+ab[i]+"]");
		}
		
		int input[] = new int[3];
		Scanner obj3 = new Scanner(System.in);
		System.out.println("\nEnter numbers one by one for array input:");
		for (int i = 0; i < 3; i++)
		{
			input[i] = obj3.nextInt();
		}
		int P[] = new int[3];
		P = expandHappy(input);
		for (int i = 0; i < P.length; i++)
		{
			System.out.print("["+P[i]+"] ");
		}
		System.out.print("\n");
		int R[] = new int[3];
		R = expandSad(input);
		for (int i = 0; i < R.length; i++)
		{
			System.out.print("["+R[i]+"] ");
		}
	
		playArray(a);
	}

}
