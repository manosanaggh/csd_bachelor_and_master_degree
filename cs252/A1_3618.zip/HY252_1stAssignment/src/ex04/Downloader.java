package ex04;
import java.io.*;
import java.net.URL;
import javax.swing.JOptionPane;

public class Downloader 
{
	static int download(String address) 
	{
		try 
		{
		URL url = new URL(address);
		BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
		int c = in.read();
		while (c != -1) 
		{
		 System.out.print((char) c);
		 c = in.read();
		}
		in.close();
		} 
		catch (Exception e) 
		{
		System.out.println(e);
		return -1;
		}
		return 0;
	}
		
	
	public static void main(String[] a) 
	{
		String toDownload = JOptionPane.showInputDialog("Enter an address: ","");
		System.out.println(toDownload);
		String f = JOptionPane.showInputDialog("Enter the directory where you want the address to be saved: ","");
		long startTime = System.nanoTime();
		File f1 = new File(f);
		try
		{
		FileWriter writer = new FileWriter(f1);
		writer.write(toDownload);
		writer.close();
		}
		catch (Exception e)
		{
			System.out.println("error");
		}
        long endTime = System.nanoTime();
        long timeInNanosecs = endTime - startTime;
		download(toDownload);
		System.out.print("The download duration is: "+timeInNanosecs);
	}


}
