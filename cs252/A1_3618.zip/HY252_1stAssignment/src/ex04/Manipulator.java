package ex04;
import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;

public class Manipulator{
	
	private File f1, f2, f3;
	
	public void openFilesandWrite()
	{
		try
    	{
			JFileChooser fileChooser = new JFileChooser();
		  	 fileChooser.setDialogTitle("Select a file");
		  	 int userSelection = fileChooser.showSaveDialog(null);
		  	 if (userSelection == JFileChooser.APPROVE_OPTION) 
		  	 {
		  	   File file = fileChooser.getSelectedFile();
		  	   String filepath = file.getAbsolutePath();
		  	   f1 = new File(filepath);
		  	  
		  	   System.out.println("The path of the selected file is: " + filepath);
		  	 }
		  	 
		  	JFileChooser fileChooser2 = new JFileChooser();
		  	 fileChooser2.setDialogTitle("Select a file");
		  	 int userSelection2 = fileChooser2.showSaveDialog(null);
		  	 if (userSelection2 == JFileChooser.APPROVE_OPTION) 
		  	 {
		  	   File file2 = fileChooser2.getSelectedFile();
		  	   String filepath2 = file2.getAbsolutePath();
		  	   
		  	   f2 = new File(filepath2);
		  	   System.out.println("The path of the selected file is: " + filepath2);
		  	 }
		  	 
		  	JFileChooser fileChooser3 = new JFileChooser();
		  	 fileChooser3.setDialogTitle("Select a file");
		  	 int userSelection3 = fileChooser3.showSaveDialog(null);
		  	 if (userSelection3 == JFileChooser.APPROVE_OPTION) 
		  	 {
		  	   File file3 = fileChooser3.getSelectedFile();
		  	   String filepath3 = file3.getAbsolutePath();
		  	   f3 = new File(filepath3);
		  	 
		  	   System.out.println("The path of the selected file is: " + filepath3);
		  	 }
		  	 
		  	 

    		Scanner istring = new Scanner(System.in);
    		Scanner iwords = new Scanner(System.in);
    		
    		String s;
    		
    		int words;
    		System.out.print("Enter number of words you want to write: ");
    		words = iwords.nextInt();
    		
    		BufferedWriter writer1 = new BufferedWriter (new FileWriter(f1));
    		BufferedWriter writer3 = new BufferedWriter (new FileWriter(f3));
    		
    		for (int i = 0; i < words; i++)
    		{
    			System.out.print("Enter a string: ");
    			s = istring.next();
    			writer1.write(s);
    			writer3.write(s);
    			writer1.write(" ");
    			writer3.write(" ");
    		}
    		
    		writer1.close();
    		writer3.close();
    	}
    	catch (Exception e)
    	{
    		System.out.println("Error");
    	}
	}
	
	public void replace1to2()
	{
		try
		{
			BufferedReader fr = new BufferedReader(new FileReader(f1));
			Scanner scanner = new Scanner(System.in);
			
			//f2 = new File("File2.txt");

			BufferedWriter writer2 = new BufferedWriter (new FileWriter(f2));
			
			System.out.print("Enter number of words you want to replace: ");
			int repwords = scanner.nextInt();
			
			String nL = "";
			for (int i = 0; i < repwords; )
			{
				System.out.print("Enter past line to be replaced: ");
				String oldline = scanner.next();
				writer2.write(oldline);
				writer2.write(" ");
			    
				System.out.print("Enter new line to replace the past line: ");
				String newline = scanner.next();
				writer2.write(newline);
				writer2.write(" ");
				writer2.newLine();
			
				String line;
	
				while ((line = fr.readLine()) != null)
				{
					nL += line + "\n";
				}
	    
			
				nL = nL.replace(oldline,newline); 
			
			
				FileOutputStream writer = new FileOutputStream(f3);
				writer.write(nL.getBytes());
				
				writer.close();
				i++;
			}
			
			writer2.close();
			fr.close();
		}
		catch (Exception e)
		{
			System.out.println("error");
		}
	}
	
	public static void main(String[] args)
	{
    	Manipulator obj= new Manipulator();
    	obj.openFilesandWrite();
    	obj.replace1to2();
    }
}
