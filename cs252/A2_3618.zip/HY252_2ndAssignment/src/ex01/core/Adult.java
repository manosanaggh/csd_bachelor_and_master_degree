package ex01.core;

import java.util.Scanner;

public class Adult extends Person{
	private String drivingLicenseId;
	private Scanner sc = new Scanner(System.in);

	public Adult(String drivingLicenseId, String name, String surname, String IDnum, Gender gender)
	{
		super(name , surname, IDnum, gender);
		this.drivingLicenseId = drivingLicenseId;
	}
	
	public void setDrivingLicenseId()
	{
		System.out.print("Enter your Driving License ID: ");
		this.drivingLicenseId = sc.next();
	}
	
	public String getDrivingLicenseId()
	{
		return this.drivingLicenseId;
	}
	
	public String toString(String drivingLicenseId)
	{
		return this.drivingLicenseId+" "+super.toString(super.getName(),super.getSurname(),super.getIDnum(),super.getGender());
	}
}


