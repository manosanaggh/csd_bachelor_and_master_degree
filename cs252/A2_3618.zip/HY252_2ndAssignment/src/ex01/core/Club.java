package ex01.core;

import java.util.Scanner;

public class Club{
	private String name;
	private int maxmembers;
	private Scanner sc = new Scanner(System.in);
	private int c = 0, m = 0, fm = 0;
	
	public Club(String name, int maxmembers) 
	{
		this.name = name;
		this.maxmembers = maxmembers;
	}
	
	public void setName()
	{
		System.out.print("Enter Club Name: ");
		this.name = sc.next();
	}
	
	public void setMaxmembers()
	{
		System.out.print("Enter max number of members: ");
		this.maxmembers = sc.nextInt();
	}
	
	private Person[] members = new Person[100]; 
	
	public void addMember(Person p)
	{	
		Adult a = new Adult("","","","",Person.Gender.Male);
		for (int i = 0; i < this.maxmembers; i++)
		{
			System.out.println("***addMember***");
			if (i < this.maxmembers-1)
			{
				a.setName();
				c++;
				a.setSurname();
				c++;
				a.setIDnum();
				c++;
				a.setGender();
				c++;
				if (a.getGender() == Person.Gender.Male)
				{
					m++;
				}
				else
				{
					fm++;
				}
				a.setDrivingLicenseId();
				c++;
				if (members[i] == null)
				{
					members[i] = new Adult(a.getDrivingLicenseId(),a.getName(),a.getSurname(),a.getIDnum(),a.getGender());
				}
			}
			else
			{
				p.setName();
				c++;
				p.setSurname();
				c++;
				p.setIDnum();
				c++;
				p.setGender();
				c++;
				if (a.getGender() == Person.Gender.Male)
				{
					m++;
				}
				else
				{
					fm++;
				}
				if (members[i] == null)
				{
				    members[i] = new Person(p.getName(), p.getSurname() , p.getIDnum(), p.getGender());
				}
			}
		}
	}
	
	
	public void deleteMember(Person p)
	{
		for (int i = 0; i < this.maxmembers; i++)
		{
			System.out.println("***deleteMember***");
			p = new Person(p.getName(), p.getSurname(), p.getIDnum(), Person.Gender.Male);
			if (p.getIDnum() == members[i].getIDnum())
			{
				members[i] = null;
				for (int j = i+1; j < this.maxmembers; j++)
				{
					members[j-1] = members[j];
				}
			}
		}
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public int getMaxmembers()
	{
		return this.maxmembers;
	}
	
	public Person[] getMembers()
	{
		return members;
	}
	
	public int getC()
	{
		return c;
	}
	
	public int getM()
	{
		return m;
	}
	
	public int getFM()
	{
		return fm;
	}

	public String toString() 
	{
	   return this.name+ " "+this.maxmembers;
	}


}
