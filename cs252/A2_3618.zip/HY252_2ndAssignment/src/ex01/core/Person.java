package ex01.core;

import java.util.*;

public class Person {
	private String name;
	private String surname;
	private Gender gender;
	private String IDnum;
	private Scanner sc = new Scanner(System.in);
	
	public enum Gender 
	{
		Male, Female
	}
	
	public Person(String name, String surname, String IDnum, Gender gender) 
	{
		this.name = name;
		this.surname = surname;
		this.IDnum = IDnum;
		this.gender = gender;
	}
	
	public void setName()
	{
		System.out.print("Enter your name: ");
		this.name = sc.next();
	}
	
	public void setSurname()
	{
		System.out.print("Enter your surname: ");
		this.surname = sc.next();
	}
	
	public void setIDnum()
	{
		System.out.print("Enter your ID: ");
		this.IDnum = sc.next();
	}
	
	public void setGender()
	{
		System.out.print("Enter your Gender: ");
		this.gender = Gender.valueOf(sc.next());
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public String getSurname()
	{
		return this.surname;
	}
	
	public String getIDnum()
	{
		return this.IDnum;
	}
	
	public Gender getGender()
	{
		return this.gender;
	}
	
	public String toString(String name, String surname, String IDnum, Gender gender)
	{
		return name+" "+surname+" "+IDnum+" "+gender; 
	}
	
}
