package ex01.core;

public class RacingClub extends Club{
	private String name;
	private int maxmembers;
	private int a = 0, nota = 0;
	private float posostoM, posostoFM;
	
	public RacingClub() 
	{
		super("",1);
		super.setName();
		super.setMaxmembers();
		this.name = super.getName();
		this.maxmembers = super.getMaxmembers();
	}
	
	public void callAddMember()
	{
		super.addMember(new Person("", "", "", Person.Gender.Male));
	}
	
	public void callDeleteMember()
	{
		Person[] temp = super.getMembers();
		super.deleteMember(new Person(temp[19].getName(),temp[19].getSurname(), temp[19].getIDnum(),temp[19].getGender()));
		super.deleteMember(new Person(temp[39].getName(),temp[39].getSurname(), temp[39].getIDnum(),temp[39].getGender()));
	}
	
	public String toString() 
	{
		Person[] membs = super.getMembers();
		for(int i = 0; i < maxmembers; i++)
		{
			if (membs[i] instanceof Adult)
			{
				a++;
				System.out.println(((Adult)membs[i]).toString(((Adult)membs[i]).getDrivingLicenseId()));
			}
			else
			{
				nota++;
				System.out.println(membs[i].toString(membs[i].getName(),membs[i].getSurname(), membs[i].getIDnum(), membs[i].getGender()));
			}
		}
		posostoM = ((float)super.getM()/(float)(a+nota))*100;
		posostoFM= ((float)super.getFM()/(float)(a+nota)*100);
		return this.name+" "+super.getC()+" "+posostoM+" "+posostoFM;
	}
	
	public int getNumberOfMembers()
	{
		return a+nota;
	}
	
	
	public int getNumberOf�dultMembers()
	{
		return a;
	}
	

}
