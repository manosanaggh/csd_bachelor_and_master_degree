package ex01.test;

import ex01.core.RacingClub;

public class RacingClubTester{
	public static void main(String[] args)
	{			
		RacingClub rc = new RacingClub();
		rc.callAddMember();
		System.out.println(rc.toString());
		System.out.println(rc.getNumberOfMembers());
		System.out.println(rc.getNumberOf�dultMembers());
		RacingClub rc2 = new RacingClub();
		rc2.callAddMember();
		rc2.callDeleteMember();
		System.out.println(rc2.toString());
		System.out.println(rc2.getNumberOfMembers());
		System.out.println(rc2.getNumberOf�dultMembers());
		
	}
}
