package ex02.�;

public class EWallet {
	private double maxCash;
	private double moneyLeft;
	private int PIN;
	
	public EWallet(double maxCash,double moneyLeft,int PIN)
	{
		this.maxCash = maxCash;
		this.moneyLeft = moneyLeft;
		this.PIN = PIN;
	}
	
	public void setPIN(int PIN) 
	{
		this.PIN = PIN;
	}
	
	public double getMoneyLeft()
	{
		return moneyLeft;
	}
	
	public void changePIN(int PIN,int newPIN) throws IllegalArgumentException
	{
		if(this.PIN != 0)
		{
		    if (this.PIN == PIN)
			{
				this.PIN = newPIN;
				System.out.println("PIN successfuly changed");
			}
			else
			{
				throw new IllegalArgumentException("~WRONG PIN, TRY AGAIN~");
			}
			}
		else
		{
			throw new IllegalArgumentException("~NO PIN WAS SET~");
		}
	}
	
	
	public void addMoney(int PIN,int amount) throws IllegalArgumentException
	{
		    if (this.PIN != 0)
			{
		        if(this.PIN == PIN)
		        {
		        	if (maxCash - moneyLeft >= amount)
		        	{
		        		moneyLeft += amount;
		        		System.out.println("amount "+amount+" successfuly added");
		        	}
		        	else 
		        	{
		        		throw new IllegalArgumentException("~YOU CAN'T ADD THAT MUCH MONEY: "+amount+", NOT ENOUGH ACCOUNT CAPACITY: "+(maxCash-moneyLeft)+"~");
		        	}
		        }
		        else
		        {
		        	throw new IllegalArgumentException("~WRONG PIN, TRY AGAIN~");
		        }
			}
			else
			{
				throw new IllegalArgumentException("~NO PIN WAS SET~");
			}
	}

	public void takeMoney(int PIN, int amount) throws IllegalArgumentException 
	{
		if (this.PIN != 0)
		{
			if(this.PIN == PIN)
			{
				if (moneyLeft >= amount)
				{
					moneyLeft -= amount;
					System.out.println("amount "+amount+" successfuly taken");
				}
				else
				{
					throw new IllegalArgumentException("~YOU CAN'T TAKE THAT MUCH MONEY: "+amount+", THE AMOUNT LEFT IN YOUR ACCOUNT IS LESS THAN THAT: "+moneyLeft+"~");
				}
			}
			else
			{
				throw new IllegalArgumentException("~WRONG PIN, TRY AGAIN~");
			}
		}
		else
		{
			throw new IllegalArgumentException("~NO PIN WAS SET~");
		}
	}
	
	
}
