package ex02.�;

import ex02.�.EWallet;
public class EWalletClient {
	public static void main(String[] args)
	{
		EWallet ew = new EWallet(1000, 0.0, 0);
		
		try
		{
			ew.addMoney(1111,100);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		ew.setPIN(1111);
			
		try
		{
		    ew.addMoney(1111, 250);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
		    ew.addMoney(1111, 250);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
		    ew.addMoney(1111, 250);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
		    ew.addMoney(1111, 250);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
		    ew.addMoney(1111, 250);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
			
		try
		{
		    ew.changePIN(2222, 3333);
		    System.out.println("ok");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
			ew.changePIN(1111, 3333);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
			ew.takeMoney(3333, 400);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
			ew.takeMoney(3333, 400);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
			ew.takeMoney(3333, 400);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try
		{
			ew.takeMoney(3333, 400);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		System.out.println("Money Left: "+ew.getMoneyLeft());
	}
}

