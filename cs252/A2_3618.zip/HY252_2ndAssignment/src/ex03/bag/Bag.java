package ex03.bag;

import ex03.trainer.BagCarrier;
import ex03.trainer.Trainer;
import java.util.ArrayList;
public class Bag {

	private int maxCapacity;
	private BagCarrier holder;
	private ArrayList<Item>items = new ArrayList<Item>();
	
	public Bag() 
	{
		this.maxCapacity = 10;
	}
	
	public void addItem(Item item) throws IndexOutOfBoundsException 
	{
		if (items.size() < this.maxCapacity)
		{
            items.add(item);
		}
		else
		{
			throw new IndexOutOfBoundsException ("The bag is Full");
		}
	}
	
	public Medicine getMedicineItem()  
	{
		for(int i = 0; i < items.size(); i++)
		{
		if(items.get(i) instanceof Medicine && items.get(i) != null)
		{
			Medicine medicine = (Medicine)items.get(i);
			items.remove(i);
			return (Medicine)medicine;
		}
		}
		return null;
	}
	
	public Berry getBerryItem() 
	{
		for(int i = 0; i < items.size(); i++)
		{
		if(items.get(i) instanceof Berry && items.get(i) != null)
		{
			Berry berry = (Berry)items.get(i);
			items.remove(i);
			return (Berry)berry;
		}
		}
		return null;
	}
	
	public void setHolder(Trainer holder)
	{
		this.holder = holder;
	}
	
	public BagCarrier getHolder() 
	{
		return this.holder;
	}
	
	public String toString() 
	{
		return ""+items;
	}
}
