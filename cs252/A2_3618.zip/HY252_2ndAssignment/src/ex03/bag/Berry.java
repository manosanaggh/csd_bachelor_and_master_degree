package ex03.bag;

import ex03.pokemon.Pokemon;
import java.util.Random;

public class Berry extends Item{

	private final int attackSkill;
	
	public Berry() 
	{
		super("Berry_");
		this.attackSkill = new Random().nextInt(5 - 2 +1) + 2;
	}
	
	public void carePokemon(Pokemon pokemon) 
	{
		try
		{
		    pokemon.setAttack(pokemon.getAttack() + attackSkill);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	
	public String toString() 
	{
		return "\n{Item: "+getName()+" ,attackSkill: "+this.attackSkill+"}";
	}
	
	

}
