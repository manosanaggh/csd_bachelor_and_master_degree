package ex03.bag;
import ex03.pokemon.Pokemon;
public abstract class Item {

	private final String name;
	private static int counter = 0;
	
	public Item(String name) 
	{
		if (name != "")
		{	
		    this.name = name+counter;
		    counter++;
		}
		else
		{
			throw new RuntimeException("~name is empty~");
	    }
	}

	public String getName()
	{
		return this.name;
	}
	
	abstract public void carePokemon(Pokemon pokemon);
	
	abstract public String toString();

}
