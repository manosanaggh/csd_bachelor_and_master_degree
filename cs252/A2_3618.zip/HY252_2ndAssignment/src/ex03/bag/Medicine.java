package ex03.bag;

import ex03.pokemon.Pokemon;
import java.util.Random;

public class Medicine extends Item{

	private final int medicineSkill;
	
	public Medicine()  
	{	
		super("Medicine_");
		this.medicineSkill = new Random().nextInt(10 - 4 +1) + 4;
	}
	
	public void carePokemon(Pokemon pokemon) 
	{
		  pokemon.setHealthCondition(pokemon.getHealthCondition() + medicineSkill);
	}
	
	public String toString() 
	{
		return "\n{Item: "+getName()+" ,medicineSkill: "+this.medicineSkill+"}";
	}

}
