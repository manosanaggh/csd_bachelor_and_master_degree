package ex03.pokemon;
import java.util.ArrayList;
public class FirePokemon extends Pokemon{
	
	public FirePokemon(String name, int attack, int healthPwr) 
	{
		super(name, attack, healthPwr,new ArrayList<String>() {{add("GrassPokemon");}},new ArrayList<String>() {{add("RockPokemon");add("WaterPokemon");}} );
	}
	
	public FirePokemon(String name)
	{
		super(name, new ArrayList<String>() {{add("GrassPokemon");}},new ArrayList<String>() {{add("RockPokemon");add("WaterPokemon");}} );
	}
}
