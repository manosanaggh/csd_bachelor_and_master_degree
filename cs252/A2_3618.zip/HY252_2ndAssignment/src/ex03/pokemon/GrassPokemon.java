package ex03.pokemon;

import java.util.ArrayList;

public class GrassPokemon extends Pokemon{
	
	public GrassPokemon(String name, int attack, int healthPwr)
	{
		super(name, attack, healthPwr,new ArrayList<String>() {{add("RockPokemon");add("WaterPokemon");}},new ArrayList<String>() {{add("FirePokemon");}} );
	}
	
	public GrassPokemon(String name) 
	{
		super(name, new ArrayList<String>() {{add("RockPokemon");add("WaterPokemon");}},new ArrayList<String>() {{add("FirePokemon");}} );
	}

}
