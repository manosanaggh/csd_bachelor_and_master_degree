package ex03.pokemon;

public interface Playable {

	public void attack(Pokemon adversary) throws Exception;
	
	public boolean isDefeated();
	
	public int getHealthCondition();
	
	public void setHealthCondition(int condition);
	
	public String getCallSign();

}
