package ex03.pokemon;

import java.util.ArrayList;
import ex03.trainer.Trainer;

public abstract class Pokemon implements Playable {
	private final String name;
	private int attack;
	private int healthPwr;
	private final ArrayList<String> strongAgainst = new ArrayList<String>();
	private final ArrayList<String> weakAgainst = new ArrayList<String>();
	private Trainer trainer;
	
	public Pokemon(String name, int attack, int healthPwr, ArrayList<String>strongAgainst, ArrayList<String>weakAgainst) 
	{
	    if(name == "")
		{
			throw new RuntimeException("~name is empty~");
		}
		else
		{
			this.name = name;
	    }
	
		if(attack < 1 || attack > 10)
		{
			throw new RuntimeException("~attack out of bounds [1,10]~");
		}
		else
		{
		    this.attack = attack;
		}
		
		if(healthPwr < 0 || healthPwr > 20)
		{
			throw new RuntimeException("~healthPwr out of bounds [0,20]~");
		}
		else
		{
		    this.healthPwr = healthPwr;
		}
		this.strongAgainst.addAll(strongAgainst);
		this.weakAgainst.addAll(weakAgainst);
		this.trainer = null;
	}
	
	public Pokemon(String name, ArrayList<String>strongAgainst, ArrayList<String>weakAgainst) 
	{
		if(name == "")
		{
			throw new RuntimeException("~name is empty~");
		}
		else
		{
		this.name = name;
		}
		
		this.attack = 5;
		this.healthPwr = 15;
		this.strongAgainst.addAll(strongAgainst);
		this.weakAgainst.addAll(weakAgainst);
		this.trainer = null;
	}
	
	public void attack(Pokemon adversary) throws IllegalArgumentException  
	{
		if(!this.equals(adversary))
		{
			if(this.healthPwr > 0)
			{
				if (isStrongAgainst(adversary))
				{
				    adversary.setHealthCondition(adversary.healthPwr - attack * 2);
				}
				else if (isWeakAgainst(adversary))
				{
					adversary.setHealthCondition(adversary.healthPwr - attack / 2);
				}
				else
				{
					adversary.setHealthCondition(adversary.healthPwr - attack);
				}
				System.out.println(this.name+" attacked "+adversary.name+" and reduced his health to "+adversary.getHealthCondition()+"\n");
			}
			else
			{
				throw new IllegalArgumentException("~a fainted pokemon cannot attack~");
			}
		}
		else
		{
			throw new IllegalArgumentException("~a pokemon cannot attack itself~");
		}
	}
	
	public void setHealthCondition(int condition) 
	{
	    healthPwr = condition;
	}
	
	public int getHealthCondition()
	{
		return healthPwr;
	}
		
		
	
	public boolean isDefeated() 
	{
		if (getHealthCondition() > 0)
		{
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	public String getCallSign() 
	{
			return this.name;
	}
	
	public void setAttack(int attack) throws IllegalArgumentException 
	{
		if(attack < 1)
		{
			throw new IllegalArgumentException("~attack less than 1~");
		}
		else
		{
		    this.attack = attack;
		}
	}
	
	public int getAttack() 
	{
		return this.attack;
	}
	
	public boolean isStrongAgainst(Pokemon adversary) 
	{
		for(int i = 0; i < this.strongAgainst.size(); i++)
		{
			if (this.strongAgainst.get(i).equals(adversary.getClass().getSimpleName()))
			{
				 return true;   	
			}
		}
		return false;
	}
	
	public boolean isWeakAgainst(Pokemon adversary) 
	{	
		for(int i = 0; i < this.weakAgainst.size(); i++)
		{
			if (this.weakAgainst.get(i).equals(adversary.getClass().getSimpleName()))
			{
				return true;  	
			}
		}
		return false;
	}
	
	public Trainer getTrainer() 
	{
		return this.trainer;
	}
	
	public void setTrainer(Trainer trainer) 
	{
		this.trainer = trainer;
	}
	
	
	public String toString() 
	{
		 return "\n{Pokemon: "+this.name+", attack: "+this.attack+", healthPwr: "+this.healthPwr+"}";
	}

}
