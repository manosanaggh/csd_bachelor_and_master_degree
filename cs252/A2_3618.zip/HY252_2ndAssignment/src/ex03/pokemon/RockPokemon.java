package ex03.pokemon;

import java.util.ArrayList;

public class RockPokemon extends Pokemon{
	
	public RockPokemon(String name, int attack, int healthPwr)
	{
		super(name, attack, healthPwr,new ArrayList<String>() {{add("FirePokemon");}},new ArrayList<String>() {{add("GrassPokemon");add("WaterPokemon");}} );
	}
	
	public RockPokemon(String name)
	{
		super(name, new ArrayList<String>() {{add("FirePokemon");}},new ArrayList<String>() {{add("GrassPokemon");add("WaterPokemon");}} );
	}
}
