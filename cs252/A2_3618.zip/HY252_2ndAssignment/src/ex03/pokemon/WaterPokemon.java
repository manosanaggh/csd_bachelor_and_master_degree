package ex03.pokemon;

import java.util.ArrayList;

public class WaterPokemon extends Pokemon{

	public WaterPokemon(String name, int attack, int healthPwr) 
	{
		super(name, attack, healthPwr,new ArrayList<String>() {{add("FirePokemon");add("RockPokemon");}},new ArrayList<String>() {{add("GrassPokemon");}} );
	}
	
	public WaterPokemon(String name) 
	{
		super(name, new ArrayList<String>() {{add("FirePokemon");add("RockPokemon");}},new ArrayList<String>() {{add("GrassPokemon");}} );
	}
}
