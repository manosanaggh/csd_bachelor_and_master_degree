package ex03.trainer;

import ex03.bag.Bag;
import ex03.bag.Medicine;
import ex03.bag.Berry;
import ex03.bag.Item;

public abstract class BagCarrier{

    private Bag bag = new Bag();
	
	public Bag getBag() 
	{
		return this.bag;
	}
	
	public boolean hasBag()
	{
		if(this.bag != null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void setBag(Bag bag) 
	{
		this.bag = bag;
	}
	
	public void collectItem(Item item) throws NoSuchFieldException 
	{
		if(hasBag()) 
		{
			bag.addItem(item);
		}
		else
		{
			throw new NoSuchFieldException("~No bag~");
		}	
	}
	
	public Medicine getMedicineItem() throws NoSuchFieldException 
	{
		if(hasBag()) 
		{
		    return bag.getMedicineItem();
		}
		else
		{
			throw new NoSuchFieldException("~No bag~");
		}
	}
	
		
	
	public Berry getBerryItem() throws NoSuchFieldException 
	{
		
		if(hasBag() == true) 
		{
		    return bag.getBerryItem();
		}
		else
		{
			throw new NoSuchFieldException("~No bag~");
		}
	}
}


