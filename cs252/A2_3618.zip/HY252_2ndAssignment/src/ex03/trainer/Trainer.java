package ex03.trainer;

import ex03.pokemon.Pokemon;
import java.util.ArrayList;
public class Trainer extends BagCarrier{

	private final String firstName;
	private final String lastName;
	private final ArrayList<Pokemon>caughtPokemons = new ArrayList<Pokemon>();
	
	public Trainer(String firstName, String lastName)  
	{
		if(firstName == "")
		{
			throw new RuntimeException("~firstname is empty~");
		}
		else
		{
			this.firstName = firstName;
		}
		
		if (lastName == "")
		{
			throw new RuntimeException("~lastname is empty~");
		}
		else
	    {
			this.lastName = lastName;
	    }
	}
	
	public void catchPokemon(Pokemon pokemon) 
	{
		   caughtPokemons.add(pokemon); 	   
	}
	
	public boolean isDefeated() 
	{
		if (chooseNextPokemon() == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public Pokemon chooseNextPokemon() 
	{
		for(int i = 0; i < caughtPokemons.size(); i++)
		{
			if(!caughtPokemons.get(i).isDefeated())
			{
				return caughtPokemons.get(i);
			}
		}
		return null;
	}
	
	public String getCallSign()  
	{
		return this.firstName+" "+this.lastName;
	}
	
	public String toString() 
	{
		return "Trainer: "+getCallSign()+"\nBag: "+getBag()+"\nCaught Pokemons: "+caughtPokemons+"\n";
	}
}
