package ex04.AB;

/**
 * 
 * @author Anagnostakis Manos
 * 
 * Vending Machine-Class operator
 * 
 */

public class VendingMachine implements VendingMachine_ADT {
	
	private String[] State = {"IDLE", "Money Entered", "Drink Selected", "Drink Selected && Money Entered"};
	private float totalMoneyEntered;
	private String currentState;
	private int stockNumber;
	private float dprice;
	private String[] Dname = {"cocacola", "cocacolazero", "fanta", "zelita", "sprite"};
	private double[] CDvalue = {0.05, 0.1, 0.2, 0.5, 1, 2};
	private String[] CSvalue = {"5c", "10c", "20c", "50c", "1e", "2e"};
	private String dname;
	private float cvalue;
	private String cn;
	
	public VendingMachine(double dprice,int stockNumber) /** constructor */
	{
		totalMoneyEntered = 0;
		this.dprice = (float)dprice;
		this.stockNumber = stockNumber;
		currentState = State[0];
	}

	public void selectDrink() /** mutative transformer */
	{
		if(currentState.equals(State[1]))
		{
			currentState = State[3];
			
		}
		else if(currentState.equals(State[0]))
		{
			currentState = State[2];
		}
	}
	
	public void insertCoin() /** mutative transformer */
	{
		if(currentState.equals(State[2]))
		{
			totalMoneyEntered += cvalue;
			currentState = State[3];
			
		}
		else if(currentState.equals(State[0]))
		{
			totalMoneyEntered += cvalue;
			currentState = State[1];
		}
		else 
		{
			totalMoneyEntered += cvalue;
		}
	}
	
	
	public String updateDisplay(String s) /** applicative transformer */
	{
		String ud = s;
		return ud;
	}
	
	
	public String cancel() /** accessor */
	{
		currentState = State[0];
		try
		{
			return updateDisplay(returnMoney()+"");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return "";
	}
	
	public float returnMoney() throws Exception /** mutative transformer */
	{
		float temp = totalMoneyEntered;
		totalMoneyEntered = 0;
		if (temp != 0)
		{
			return temp;
		}
		else
		{
			throw new Exception("No money entered");
		}
	}
	
	public String getState() /** applicative transformer */
	{
		return currentState;
	}
	
	public boolean drinkinStock() throws Exception /** observer */
	{
		if(stockNumber >= 1)
		{
			currentState = State[0];
			return true;
		}
		else
		{
			throw new Exception("~Stock Number = 0~");
		}
	}
	
	public boolean enoughMoney() throws Exception /** observer */
	{
	    if(dprice <= totalMoneyEntered)
	    {
	    	currentState = State[0];
	    	return true;
	    }
		else
		{
			throw new Exception("~Not enough money~");
		}
	}
	
	public float returnChange() /** mutative transformer */
	{
		float temp = totalMoneyEntered;
		temp -= dprice;
		totalMoneyEntered = 0;
		return temp;
	}
	
	public String ok()  /** accessor */
	{
		try
		{
			if(drinkinStock() && enoughMoney())
			{
				return deliverDrink();
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return "";
	}
	
	public String deliverDrink() /** mutative transformer */
	{
		stockNumber--;
		return updateDisplay("Delivering drink :"+dname+"\t"+"Change: "+returnChange());
	}
	
	public String getDrink() /** applicative transformer */
	{
	    return dname;
	}
	
	public float getMoney() /** applicative transformer */
	{
		return totalMoneyEntered;
	}
	
	public void setDrinkName() /** mutative transformer */
	{
		for(int i = 0; i < Dname.length; i++)
		{
			if(Dname[i].equals(cn))
			{
				dname = cn;
			}
		}
	}
	
	public void setCoinValue() /** mutative transformer */
	{
		for (int i = 0; i < 6; i++)
		{
			if(CSvalue[i].equals(cn))
			{
				cvalue = (float)CDvalue[i];
			}
		}
	}
	
	public void malset(String casename) /** mutative transformer */
	{
		cn = casename;
	}
	
	public float getPrice() /** applicative transformer */
	{
		return dprice;
	}
		

}
