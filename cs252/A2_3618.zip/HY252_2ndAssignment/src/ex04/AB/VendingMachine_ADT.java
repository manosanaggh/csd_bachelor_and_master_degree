package ex04.AB;

/**
 * @author Anagnostakis Manos
 *
 * Vending Machine_ADT-Abstract Data Type-Interface
 *
 */

public interface VendingMachine_ADT {
	/**
	 * Method: selectDrink()
	 * Pre-conditions: currentState.equals(State[1]) or currentState.equals(State[0]) (IDLE or Money Entered)
	 * Post-conditions: selects the desired drink.
	 */
	public void selectDrink();
	
	/**
	 * Method: insertCoin() 
	 * Pre-conditions: currentState.equals(State[2]) or currentState.equals(State[0]) or currentState.equals(State[3])-else (IDLE or Drink Selected or Drink Selected && Money Entered) 
	 * Post-conditions: inserts a coin and increases the value of money entered by its value.
	 */
	public void insertCoin();
	
	/**
	 * Method: updateDisplay(String s)
	 * Pre-conditions: there no pre-conditions.
	 * Post-conditions: @return information about the vending machine
	 */
	public String updateDisplay(String s);
	
	/**
	 * Method: cancel()
	 * Pre-conditions: invariant: temp != 0 (totalMoneyEntered != 0)
	 * Post_conditions: @return cancels the process and returns the money entered.
	 */
	public String cancel();
	
	/**
	 * Method: returnMoney()
	 * Pre-conditions: invariant: temp != 0 (totalMoneyEntered != 0)
	 * Post_conditions: @return the total money entered.
	 * @throws Exception "No money entered" 
	 */
	public float returnMoney() throws Exception;
	
	/**
	 * Method: getState()
	 * Pre-conditions: the are no pre-conditions.
	 * Post_conditions: @return the state of the vending machine.
	 */
	public String getState();
	
	/**
	 * Method: drinkinStock()
	 * Pre-conditions: stockNumber >= 1
	 * Post_conditions: @return true if stockNumber >= 1 
	 * @throws Exception ~Stock Number = 0~
	 */
	public boolean drinkinStock() throws Exception;
	
	/**
	 * Method: enoughMoney()
	 * Pre-conditions: dprice <= totalMoneyEntered
	 * Post_conditions: @return true if dprice <= totalMoneyEntered
	 * @throws Exception ~Not enough money~
	 */
	public boolean enoughMoney() throws Exception;
	
	/**
	 * Method: returnChange()
	 * Pre-conditions: invariant: drinkinStock() && enoughMoney()
	 * Post_conditions: @return the money change.
	 */
	public float returnChange();
	
	/**
	 * Method : ok()
	 * Pre-conditions: invariant: drinkinStock() && enoughMoney()
	 * Post_conditions: @return calls deliverDrink()
	 */
	public String ok();
	
	/**
	 * Method: deliverDrink()
	 * Pre-conditions: invariant: drinkinStock() && enoughMoney()
	 * Post_conditions: @return which drink is being delivered and calls returnChange().
	 */
	public String deliverDrink();
}
