package ex04.�;
import ex04.AB.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class DrinkinStockTrueTest {

	@Test
	public void test() {
		VendingMachine v = new VendingMachine(1.5, 5);
		boolean b = false;
		try
		{
		b = v.drinkinStock();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		assertEquals(true,b);
	}

}
