package ex04.�;

import static org.junit.Assert.*;

import org.junit.Test;

import ex04.AB.VendingMachine;

public class InsertCoinRemains0 {

	@Test
	public void test() {
		VendingMachine v = new VendingMachine(1.5, 5);
        float b = 0;
        v.insertCoin();
        assertEquals(b, v.getMoney(), 0);
	}

}
