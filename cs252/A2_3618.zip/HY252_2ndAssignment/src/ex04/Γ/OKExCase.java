package ex04.�;

import static org.junit.Assert.*;

import org.junit.Test;

import ex04.AB.VendingMachine;

public class OKExCase {

	@Test
	public void test() {
		VendingMachine v = new VendingMachine(1.5, 5);
		String s = v.ok();
		assertEquals("", s);
	}

}
