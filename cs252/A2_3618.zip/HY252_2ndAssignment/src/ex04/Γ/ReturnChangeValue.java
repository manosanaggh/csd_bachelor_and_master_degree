package ex04.�;

import static org.junit.Assert.*;

import org.junit.Test;

import ex04.AB.VendingMachine;

public class ReturnChangeValue {

	@Test
	public void test() {
		VendingMachine v = new VendingMachine(1.5, 5);
		float b = 0;
		try
		{
			b = v.returnChange();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		assertEquals(v.getMoney()-v.getPrice(), b, 0);
	}

}
