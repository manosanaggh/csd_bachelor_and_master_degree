package ex04.�;
import ex04.AB.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 * @author yannakis
 * Listener class for A2.4
 * Responsible for the listeners actions
 */
public class MyActionListener implements MouseListener {
    private final VendingMachine vm;//your class 
    private JLabel jlabDisplay;//the display
    volatile private String state;//IDLE, COINS INSERTED, DRINK SELECTED, BOTH, NONE 
    volatile private boolean isrunning; // a thread is running

    /**
     * The constructor
     * Initialize the state from your class
     * Change the initialization according to your needs
     * @param vm your vending machine class
     * @param jlabDisplay the display jlabel, so we can change it
     */
    public MyActionListener(VendingMachine vm, JLabel jlabDisplay){
        super();
        this.vm=vm;
        this.jlabDisplay=jlabDisplay;
        state=vm.getState();
        isrunning=false;
    }
   
    /**
     * The Listener Controller
     * You can change this function to suit your needs (maybe keep which 
     * coin/drink was selected, add more states?)
     * @param e the button that was used
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        //Check which button is clicked
        JButton b=(JButton)e.getSource();
        switch (checkInputButton(b.getText())) {
            case "OK":
                state="OK";
                newThread();
                break;
            case "Cancel":
                state="Cancel";
                newThread();
                break;
            case "cocacola":
            	vm.selectDrink();
            	state = "Drink Selected";
            	newThread();
            	break;
            case "cocacolazero":
            	vm.selectDrink();
            	state = "Drink Selected";
            	newThread();
            	break;
            case "fanta":
            	vm.selectDrink();
            	state = "Drink Selected";
            	newThread();
            	break;
            case "zelita":
            	vm.selectDrink();
            	state = "Drink Selected";
            	newThread();
            	break;
            case "sprite":
            	vm.selectDrink();
            	state = "Drink Selected";
            	newThread();
            	break;
            case "5c":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            case "10c":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            case "20c":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            case "50c":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            case "1e":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            case "2e":
            	vm.insertCoin();
            	state = "Money Entered";
            	newThread();
            	break;
            default:
                state="NONE";
                System.err.println("Should never reach this state");
                break;
        }
    }
    
    /**
     * gets the button text and returns the abstract state
     * @param str 
     * @return the state
     */
    private String checkInputButton(String str){
        String caseName=str;
        if(str.equals("cocacola"))
        {
        	caseName = "cocacola";
        	vm.malset(caseName);
        	vm.setDrinkName();
        }
        else if(str.equals("cocacolazero"))
        {
        	caseName = "cocacolazero";
        	vm.malset(caseName);
        	vm.setDrinkName();
        }
        else if(str.equals("fanta"))
        {
        	caseName = "fanta";
        	vm.malset(caseName);
        	vm.setDrinkName();
        }
        else if(str.equals("zelita"))
        {
        	caseName = "zelita";
        	vm.malset(caseName);
        	vm.setDrinkName();
        }
        else if(str.equals("sprite"))
        {
        	caseName = "sprite";
        	vm.malset(caseName);
        	vm.setDrinkName();
        }
        else if(str.equals("5c"))
        {
        	caseName = "5c";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        else if(str.equals("10c"))
        {
        	caseName = "10c";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        else if(str.equals("20c"))
        {
        	caseName = "20c";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        else if(str.equals("50c"))
        {
        	caseName = "50c";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        else if(str.equals("1e"))
        {
        	caseName = "1e";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        else if(str.equals("2e"))
        {
        	caseName = "2e";
        	vm.malset(caseName);
        	vm.setCoinValue();
        }
        return caseName;
    }
    
    /**
     * @return false if another thread is running 
     */
    private synchronized boolean checkThread(){
        return isrunning ? false : (isrunning=!isrunning);
    }
    
    /**
     * Here we handle the listener actions with new threads
     * In each action you are required to write your code accordingly to the instructions
     */
    private void newThread() {
        if(checkThread()){
            new Thread(){
                @Override
                public void run() {
                    try{
                    	switch (state){
                            case "Money Entered":
                               // your code 
                            	jlabDisplay.setText(fixTab(vm.getState()+"\t"+vm.getMoney()+"E"));
                                break;
                            case "Drink Selected":
                                 // your code
                            	jlabDisplay.setText(fixTab(vm.getState()+"\t"+vm.getDrink()+"\tPrice: "+vm.getPrice()+"E"));
                                break;
                            case "OK":
                                 // your code
                                //success example
                            	jlabDisplay.setText("Delivering Drink...  Change......");
                                sleep(1000);
                                //IDLE
                                jlabDisplay.setText(fixTab(vm.ok()));
                                break;
                            case "Cancel":
                                 // your code
                                // example
                                jlabDisplay.setText("Returning Money.....");
                                sleep(1000);
                                //IDLE
                                jlabDisplay.setText(fixTab("Money Entered: "+vm.getMoney()+" E"+"\tMoney Returned: "+vm.cancel()+" E"));
                                break;
                            default:
                                throw new Exception ("ERROR, state has not been initialised ");
                        }
                    }catch(Exception ex){ // change to your exception or modify to prevent out of order actions
                        infoBox("Wrong Order " +ex ,"ERROR");
                    }
                    isrunning=false;
                }
            }.start();
        }
    }
    
    @Override
    public void mousePressed(MouseEvent me) {}
    @Override
    public void mouseReleased(MouseEvent me) {}
    @Override
    public void mouseEntered(MouseEvent me) {}
    @Override
    public void mouseExited(MouseEvent me) {}

    public static void infoBox(String infoMessage, String titleBar)
    {
        JOptionPane.showMessageDialog(null, infoMessage, "InfoBox: " + titleBar, JOptionPane.INFORMATION_MESSAGE);
    }
    private String fixTab(String str){
        return str.replaceAll("\t", "      ");
    }
}
