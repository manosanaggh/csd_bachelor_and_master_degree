package controller;
import model.player.Player;
import model.position.*;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import model.card.*;
import model.dice.Dice;
import model.piece.Piece;
import view.*;

/**
 * Controller: controls everything
 * that is being done in the game
 * @version 1.0
 * @author Anagnostakis Manos
 */
public class Controller//diafores me A fash: KAMIA
{
	private static int mcCounter=0,dcCounter=0;//added
	private Player p1,p2;
	private Jackpot jp;//added
    //boolean isFirst deleted,String days deleted	
	private Position[] p; 
	private MailCard[] mc; 
	private DealCard[] dc;
    //Listener l deleted-all class Listener deleted
	private GUI g;
	private int duration;//not need its methods
	private ArrayList<Integer> diffmcrandoms,diffdcrandoms;//added 
	private SundaysFootballMatch sfm;
	
	/**
	 * constructor: constructs a new controller and initializes
	 * the fields needed for the game to start
	 * post-condition: constructs a new controller and creates a game with
	 * 2 players p1,p2, all the positions, the cards and the duration of the game. 
	 */
	public Controller() //diafores me A fash: KAMIA
	{
		p1 = new Player("Player 1",2500,0,0,new ArrayList<DealCard>());
		p2 = new Player("Player 2",2500,0,0,new ArrayList<DealCard>());
		p1.setDice(new Dice());
		p2.setDice(new Dice());
		p1.setHasPlayed(false);
		p2.setHasPlayed(false);
		p1.setIsFirst(false);
		p2.setIsFirst(false);
		g = new GUI();
		jp = new Jackpot(0);
		p = new Position[32];
		mc = new MailCard[48];
		dc = new DealCard[20];
		diffmcrandoms = new ArrayList<Integer>();
		diffdcrandoms = new ArrayList<Integer>();
		sfm = new SundaysFootballMatch();
		
		for(int i = 0; i < 48; i++)
		{
			if(i >= 24 && i < 32)
			{
				mc[i] = new PayTheNeighbour("PayTheNeighbour","message","order",8);
			}
			else if(i >= 32 && i < 40)
			{
				mc[i] = new MadMoney("MadMoney","message","order",8);
			}
			else if(i >= 16 && i < 24)
			{
				mc[i] = new Charity("Charity","message","order",8);
			}
			else if(i >= 8 && i < 16)
			{
				mc[i] = new Bill("Bill","message","order",8);
			}
			else if(i >= 40 && i < 48)
			{
				mc[i] = new MoveToDeal_Buyer("MoveToDeal_Buyer","message","order",8);
			}
			else 
			{
				mc[i] = new Advertisement("Advertisement","message","order",8);
			}
		}
		
		for(int i = 0; i < 20; i++)
		{
			dc[i] = new DealCard("DealCard","message","order",20);
		}
		
	    readFile("input\\dealCards_greeklish.csv","Deal");
	    readFile("input\\mailCards_greeklish.csv","Mail");
	    readFile("images\\positionIcons\\icon names for random positions.txt","Position");
	
	}
	
	/**
	 * transformer(mutative)
	 * post-condition: sets the boolean field isFirst true for whom of p1 or p2 starts first.
	 * This is being done randomly by using a greater random integer. 
	 */
	public void whosFirst() 
	{
		int r = new Random().nextInt((2-1)+1)+1;
		if(r == 1)
		{
			p1.setIsFirst(true);
		}
		else if(r == 2)
		{
			p2.setIsFirst(true);
		}
	}
	
	/**
	 * transformer(mutative)
	 * post-condition: mixes the deck for mc 
	 */
	public void mixUpMc() //mixUp broke to mixUpMc and mixUpDc
	{
        for (int i=0; i<48; i++) 
        {
        	diffmcrandoms.add(new Integer(i));
        }
        Collections.shuffle(diffmcrandoms);
	}
	
	/**
	 * transformer(mutative)
	 * post-condition: mixes the deck for dc 
	 */
	public void mixUpDc() //mixUp broke to mixUpMc and mixUpDc
	{
        for (int i=0; i<20; i++) 
        {
        	diffdcrandoms.add(new Integer(i));
        }
        Collections.shuffle(diffdcrandoms);
	}
	
	/**
	 * accessor(selector)
	 * post-condition: calls actionPerformed of Listener
	 * to do some action with the graphics
	 */
	public void performAction()
	{
    	g.getDiceButton1().addActionListener(new DiceListener());
    	g.getDiceButton2().addActionListener(new DiceListener());
    	g.getMcButton().addActionListener(new CardListener());
    	g.getDcButton().addActionListener(new CardListener());
    	g.getLoanButton1().addActionListener(new LoanListener());
    	g.getLoanButton2().addActionListener(new LoanListener());
    	g.getEndTurnButton1().addActionListener(new EndTurnListener());
    	g.getEndTurnButton2().addActionListener(new EndTurnListener());
    	g.getChoice1button().addActionListener(new DcChoiceListener());
    	g.getChoice2button().addActionListener(new DcChoiceListener());
    	g.getMyDealCards1Button().addActionListener(new MyDealCardsListener());
    	g.getMyDealCards2Button().addActionListener(new MyDealCardsListener());
    	g.getB1().addActionListener(new FootballMatchListener());
    	g.getB2().addActionListener(new FootballMatchListener());
    	g.getB3().addActionListener(new FootballMatchListener());
    	g.getB4().addActionListener(new FootballMatchListener());
	}
	
	/**
	 * accessor(selector)
	 * post-condition: starts a new game by
	 * calling the init methods of GUI class
	 */
	public void startNewGame()//diafores me A fash: KAMIA
	{
    	g.initPanels();
    	g.initButtons();
    	Collections.shuffle(g.getIconNames());
    	for (int i = 0; i < 4; i++)
    	{
    		if(i == 0)
    		{
    			g.setImages(i);
    			p[0]=new Start(0,"start");
    			p1.setPiece(new Piece(p[0]));
    			p2.setPiece(new Piece(p[0]));
    		}
    		else if(i == 2)
    		{
    			g.setImages(i);
    			p[31] = new PayDay(31,"PayDay");
    		}
    		else if(i == 3)
    		{
    			g.setImages(i);
    		}
    		else
    		{
     	        for (int x=0; x<30; x++) 
     	        {
    	            g.setImages(x);
    	            if(g.getIconNames().get(x).equals("buyer.png"))
    	            {
    	            	p[x+1] = new Buyer(x+1,"Buyer");
    	            }
    	            else if(g.getIconNames().get(x).equals("casino.png"))
    	            {
    	            	p[x+1] = new FamilyCasinoNight(x+1,"FamilyCasinoNight");
    	            }
    	            else if(g.getIconNames().get(x).equals("deal.png"))
    	            {
    	            	p[x+1] = new Deal(x+1,"Deal");
    	            }
    	            else if(g.getIconNames().get(x).equals("lottery.png"))
    	            {
    	            	p[x+1] = new Lottery(x+1,"Lottery");
    	            }
    	            else if(g.getIconNames().get(x).equals("mc1.png"))
    	            {
    	            	p[x+1] = new Mail1(x+1,"Mail1");
    	            }
    	            else if(g.getIconNames().get(x).equals("mc2.png"))
    	            {
    	            	p[x+1] = new Mail2(x+1,"Mail2");
    	            }
    	            else if(g.getIconNames().get(x).equals("radio.png"))
    	            {
    	            	p[x+1] = new RadioContest(x+1,"RadioContest");
    	            }
    	            else if(g.getIconNames().get(x).equals("sweep.png"))
    	            {
    	            	p[x+1] = new Sweepstakes(x+1,"Sweepstakes");
    	            }
    	            else if(g.getIconNames().get(x).equals("yard.png"))
    	            {
    	            	p[x+1] = new YardSale(x+1,"YardSale");
    	            }
    	        }
    		}
    	}
    	g.initLabels(p1,p2,jp);
		g.updatePiece1(p1.getPiece().getPosition().getNumber());
		g.updatePiece2(p2.getPiece().getPosition().getNumber());
		int num = 0;
		duration = 2*Integer.parseInt(JOptionPane.showInputDialog("Enter how many months you want to play: ", num));
		if(p1.getIsFirst())
		{
			JOptionPane.showMessageDialog(null, "Ksekinaei o Player 1!!!");
		}
		else if(p2.getIsFirst())
		{
			JOptionPane.showMessageDialog(null, "Ksekinaei o Player 2!!!");
		}
	}
	
	/**
	 * 
	 * @param path
	 * @param type
	 */
    private void readFile(String path,String type)//diafores me A fash: dn yphrxe
    {
        BufferedReader br = null;
           String sCurrentLine;
       try {
           br = new BufferedReader(new FileReader(path));
       } catch (FileNotFoundException ex) {
           Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
       }
           int count = 0;
       try {
           br.readLine();                
           while ((sCurrentLine = br.readLine()) != null) {
               if (type.equals("Mail"))
               {
                  g.mailCards[count] = sCurrentLine.split(",");
                   mc[count].setType(g.mailCards[count][0]);
                   mc[count].setMessage(g.mailCards[count][2]);
                   mc[count].setOrder(g.mailCards[count][3]);
                   if(!(mc[count] instanceof Advertisement) && !(mc[count] instanceof MoveToDeal_Buyer))
                   {
                	   mc[count].setPayment(Integer.parseInt(g.mailCards[count][4]));
                   }
                  count++;
               }
               else if(type.equals("Deal"))
               {
                  g.dealCards[count] = sCurrentLine.split(",");
                  dc[count].setType(g.dealCards[count][0]);
                  dc[count].setMessage(g.dealCards[count][2]);
                  dc[count].setBuyPrice(Integer.parseInt(g.dealCards[count][3]));
                  dc[count].setSellPrice(Integer.parseInt(g.dealCards[count][4]));
                  dc[count].setChoice1(g.dealCards[count][6]);
                  dc[count].setChoice2(g.dealCards[count][7]);
                  count++;
               }
               else
               {
            	  g.getIconNames().add(sCurrentLine);
            	  count++;
               }           	   
           }
           br.close();
       } catch (IOException ex) {
           Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
    
    /**
     * 
     * @author �����
     *
     */
	private class CardListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			if (button.getName().equals("Mail")) { 
				if(mc[diffmcrandoms.get(mcCounter)] instanceof PayTheNeighbour && (p1.getIsFirst() || p2.getHasPlayed()))//seira p1
				{
					if(p1.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p1.setMoney(p1.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						p2.setMoney(p2.getMoney()+ mc[diffmcrandoms.get(mcCounter)].getPayment());
						g.updatePlayer1(p1);
						g.updatePlayer2(p2);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na pareis daneio toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof MadMoney && (p1.getIsFirst() || p2.getHasPlayed()))//seira p1
				{
					if(p2.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p1.setMoney(p1.getMoney()+ mc[diffmcrandoms.get(mcCounter)].getPayment());
						p2.setMoney(p2.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						g.updatePlayer1(p1);
						g.updatePlayer2(p2);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na parei daneio o antipalos toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof Charity && (p1.getIsFirst() || p2.getHasPlayed()))//seira p1
				{
					if(p1.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p1.setMoney(p1.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						((Charity)mc[diffmcrandoms.get(mcCounter)]).payJackpot(jp);
						g.updatePlayer1(p1);
						g.updateJackpot(jp);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na pareis daneio toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof Bill  && (p1.getIsFirst() || p2.getHasPlayed()))//seira p1
				{
					g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
					((Bill)mc[diffmcrandoms.get(mcCounter)]).addBill(p1);
					g.updatePlayer1(p1);
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof MoveToDeal_Buyer  && (p1.getIsFirst() || p2.getHasPlayed()))
				{
					g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
					for(int i = p1.getPiece().getPosition().getNumber(); i < p.length; i++)
					{
						if(p[i] instanceof Deal)
						{
							p1.movePiece(p[i]);
							g.updatePiece1(p1.getPiece().getPosition().getNumber());
							break;
						}
						else if(p[i] instanceof Buyer)
						{
							p1.movePiece(p[i]);
							g.updatePiece1(p1.getPiece().getPosition().getNumber());
							break;
						}
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof PayTheNeighbour && (p2.getIsFirst() || p1.getHasPlayed()))//seira p2
				{
					if(p2.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p2.setMoney(p2.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						p1.setMoney(p1.getMoney()+ mc[diffmcrandoms.get(mcCounter)].getPayment());
						g.updatePlayer1(p1);
						g.updatePlayer2(p2);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na pareis daneio toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof MadMoney && (p2.getIsFirst() || p1.getHasPlayed()))//seira p2
				{
					if(p1.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p2.setMoney(p2.getMoney()+ mc[diffmcrandoms.get(mcCounter)].getPayment());
						p1.setMoney(p1.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						g.updatePlayer1(p1);
						g.updatePlayer2(p2);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na parei daneio o antipalos toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof Charity && (p2.getIsFirst() || p1.getHasPlayed()))//seira p2
				{
					if(p2.getMoney() >= mc[diffmcrandoms.get(mcCounter)].getPayment())
					{
						g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
						p2.setMoney(p2.getMoney()- mc[diffmcrandoms.get(mcCounter)].getPayment());
						((Charity)mc[diffmcrandoms.get(mcCounter)]).payJackpot(jp);
						g.updatePlayer2(p2);
						g.updateJackpot(jp);
					}
					else 
					{
						JOptionPane.showMessageDialog(g, "Prepei na pareis daneio toulaxiston "+mc[diffmcrandoms.get(mcCounter)].getPayment(), "Not enough Money", JOptionPane.WARNING_MESSAGE);
						mcCounter--;
					}
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof Bill  && (p2.getIsFirst() || p1.getHasPlayed()))//seira p2
				{
					g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
					((Bill)mc[diffmcrandoms.get(mcCounter)]).addBill(p2);
					g.updatePlayer2(p2);
				}
				else if(mc[diffmcrandoms.get(mcCounter)] instanceof MoveToDeal_Buyer  && (p2.getIsFirst() || p1.getHasPlayed()))
				{
					g.showMailCard(mc[diffmcrandoms.get(mcCounter)],diffmcrandoms.get(mcCounter));
					for(int i = p2.getPiece().getPosition().getNumber(); i < p.length; i++)
					{
						if(p[i] instanceof Deal)
						{
							p2.movePiece(p[i]);
							g.updatePiece2(p2.getPiece().getPosition().getNumber());
							break;
						}
						else if(p[i] instanceof Buyer)
						{
							p2.movePiece(p[i]);
							g.updatePiece2(p2.getPiece().getPosition().getNumber());
							break;
						}
					}
				}
				mcCounter++;
				if(mcCounter == 48)
				{
					mcCounter = 0;
					mixUpMc();
				}
				
			} 
			else if (button.getName().equals("Deal")) 
			{
				g.showDealCard(dc[diffdcrandoms.get(dcCounter)],diffdcrandoms.get(dcCounter));
				dcCounter++;
				if(dcCounter == 20)
				{
					dcCounter = 0;
					mixUpDc();
				}
			}
		}
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class DiceListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e)
		{
			JButton button = (JButton) e.getSource();
			if(button.getName().equals("Dice1") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				p1.rollDice();
				System.out.println(p1.getDice());
				jp.won(p1);
				g.updateJackpot(jp);
				g.updatePlayer1(p1);
				if(p[p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber()].equals(p[7]) || p[p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber()].equals(p[14]) || p[p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber()].equals(p[21]) || p[p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber()].equals(p[28]))
				{
					JButton[] options = {g.getB1(),g.getB2(),g.getB3(),g.getB4()};
			         JOptionPane.showOptionDialog(g,
			        		 "An theleis stoixhmatise 500 eurw ston podosfairiko agwna: \n",
			        		 "Sundays Football Match",
			         JOptionPane.OK_OPTION,
			         0,
			         new ImageIcon("images\\barcelona_real.jpg"),
			         options,
			         options[0]);
				}
				
				if(p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber() > 31)
				{
					p1.movePiece(p[31]);
				}
				else
				{
					p1.movePiece(p[p1.getPiece().getPosition().getNumber()+p1.getDice().getNumber()]);
				}
				System.out.println(p1.getPiece().getPosition());
				if(p1.getPiece().getPosition() instanceof FamilyCasinoNight)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					((FamilyCasinoNight)p1.getPiece().getPosition()).payOrGetPayed(jp,p1,p1.getDice());
					g.updatePlayer1(p1);
					g.updateJackpot(jp);
				}
				else if(p1.getPiece().getPosition() instanceof Lottery)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					int num = 0;
					int num1 = Integer.parseInt(JOptionPane.showInputDialog("Guess roll number: ", num));
					int num2 = Integer.parseInt(JOptionPane.showInputDialog("Guess roll number: ", num));
					((Lottery)p1.getPiece().getPosition()).rollDice(p1, p2, num1, num2);
					g.updatePlayer1(p1);
					g.updatePlayer2(p2);
				}
				else if(p1.getPiece().getPosition() instanceof RadioContest)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					((RadioContest)p1.getPiece().getPosition()).rollDice(p1, p2);
					g.updatePlayer1(p1);
					g.updatePlayer2(p2);
				}
				else if(p1.getPiece().getPosition() instanceof YardSale)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					((YardSale)p1.getPiece().getPosition()).wellBought(p1);
					g.updatePlayer1(p1);
				}
				else if(p1.getPiece().getPosition() instanceof Sweepstakes)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					((Sweepstakes)p1.getPiece().getPosition()).rollDice(p1);
					g.updatePlayer1(p1);
				}
				else if(p1.getPiece().getPosition() instanceof Buyer)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
				}
				else if(p1.getPiece().getPosition() instanceof Mail1)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					
				}
				else if(p1.getPiece().getPosition() instanceof Mail2)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					
				}
				else if(p1.getPiece().getPosition() instanceof Deal)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());
					
				}
				else if(p1.getPiece().getPosition() instanceof PayDay)
				{
					g.updatePiece1(p1.getPiece().getPosition().getNumber());	
					((PayDay)p1.getPiece().getPosition()).salary(p1);
					((PayDay)p1.getPiece().getPosition()).payBills(p1);
					((PayDay)p1.getPiece().getPosition()).payTax(p1);
					((PayDay)p1.getPiece().getPosition()).payLoan(p1);
					((PayDay)p1.getPiece().getPosition()).initPiece(p1.getPiece(),p[0],duration);
					duration--;
					g.updatePlayer1(p1);
					if(p1.isWinner(p2,p2.getPiece().getPosition(),duration))
					{
						JOptionPane.showMessageDialog(g, "Nikhse o Player 1!!!");
					}
				}
				if(p1.getIsFirst())
				{
					p1.setIsFirst(false);
				}
			}
			else if(button.getName().equals("Dice2") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				p2.rollDice();
				System.out.println(p2.getDice());
				jp.won(p2);
				g.updateJackpot(jp);
				g.updatePlayer2(p2);
				
				if(p[p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber()].equals(p[7]) || p[p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber()].equals(p[14]) || p[p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber()].equals(p[21]) || p[p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber()].equals(p[28]))
				{
					JButton[] options = {g.getB1(),g.getB2(),g.getB3(),g.getB4()};
			         JOptionPane.showOptionDialog(g,
			        		 "An theleis stoixhmatise 500 eurw ston podosfairiko agwna: \n",
			        		 "Sundays Football Match",
			         JOptionPane.OK_OPTION,
			         0,
			         new ImageIcon("images\\barcelona_real.jpg"),
			         options,
			         options[0]);
				}
				
				if(p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber() > 31)
				{
					p2.movePiece(p[31]);
				}
				else
				{
					p2.movePiece(p[p2.getPiece().getPosition().getNumber()+p2.getDice().getNumber()]);
				}
				System.out.println(p2.getPiece().getPosition());
				if(p2.getPiece().getPosition() instanceof FamilyCasinoNight)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					((FamilyCasinoNight)p2.getPiece().getPosition()).payOrGetPayed(jp,p2,p2.getDice());
					g.updatePlayer1(p2);
					g.updateJackpot(jp);
				}
				else if(p2.getPiece().getPosition() instanceof Lottery)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					int num = 0;
					int num1 = Integer.parseInt(JOptionPane.showInputDialog("Guess roll number: ", num));
					int num2 = Integer.parseInt(JOptionPane.showInputDialog("Guess roll number: ", num));
					((Lottery)p2.getPiece().getPosition()).rollDice(p1, p2, num1, num2);
					g.updatePlayer1(p1);
					g.updatePlayer2(p2);
				}
				else if(p2.getPiece().getPosition() instanceof RadioContest)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					((RadioContest)p2.getPiece().getPosition()).rollDice(p1, p2);
					g.updatePlayer1(p1);
					g.updatePlayer2(p2);
				}
				else if(p2.getPiece().getPosition() instanceof YardSale)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					((YardSale)p2.getPiece().getPosition()).wellBought(p2);
					g.updatePlayer2(p2);
				}
				else if(p2.getPiece().getPosition() instanceof Sweepstakes)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					((Sweepstakes)p2.getPiece().getPosition()).rollDice(p2);
					g.updatePlayer2(p2);
				}
				else if(p2.getPiece().getPosition() instanceof Buyer)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
				}
				else if(p2.getPiece().getPosition() instanceof Mail1)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					
				}
				else if(p2.getPiece().getPosition() instanceof Mail2)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					
				}
				else if(p2.getPiece().getPosition() instanceof Deal)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					
				}
				else if(p2.getPiece().getPosition() instanceof PayDay)
				{
					g.updatePiece2(p2.getPiece().getPosition().getNumber());
					((PayDay)p2.getPiece().getPosition()).salary(p2);
					((PayDay)p2.getPiece().getPosition()).payBills(p2);
					((PayDay)p2.getPiece().getPosition()).payTax(p2);
					((PayDay)p2.getPiece().getPosition()).payLoan(p2);
					((PayDay)p2.getPiece().getPosition()).initPiece(p2.getPiece(),p[0],duration);
					g.updatePlayer2(p2);
					duration--;
					if(p2.isWinner(p1,p1.getPiece().getPosition(),duration))
					{
						JOptionPane.showMessageDialog(g, "Nikhse o Player 2!!!");
					}
				}
				if(p2.getIsFirst())
				{
					p2.setIsFirst(false);
				}
			}

		}
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class LoanListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			if(button.getName().equals("Loan1"))
			{
				int num = 0;
				int loan = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of loan: ", num));
				if(loan % 1000 == 0)
				{
					p1.setLoan(p1.getLoan()+loan);
					p1.setMoney(p1.getMoney()+loan);
					g.updatePlayer1(p1);
				}
				else
				{
					JOptionPane.showMessageDialog(g, "To daneio prepei na einai pollaplasio twn 1000 eurw(px. 1000,2000,3000 klp)", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
			else if(button.getName().equals("Loan2"))
			{
				int num = 0;
				int loan = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of loan: ", num));
				if(loan % 1000 == 0)
				{
					p2.setLoan(p2.getLoan()+loan);
					p2.setMoney(p2.getMoney()+loan);
					g.updatePlayer2(p2);
				}
				else
				{
					JOptionPane.showMessageDialog(g, "To daneio prepei na einai pollaplasio twn 1000 eurw(px. 1000,2000,3000 klp)", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
		
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class EndTurnListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			JButton button = (JButton) e.getSource();
			if(button.getName().equals("EndTurn1"))
			{
				p1.setHasPlayed(true);
				p2.setHasPlayed(false);
				JOptionPane.showMessageDialog(null, "Teleiwse o guros tou Player 1. Ksekinaei o guros tou Player 2.");
			}
			else if(button.getName().equals("EndTurn2"))
			{
				p2.setHasPlayed(true);
				p1.setHasPlayed(false);
				JOptionPane.showMessageDialog(null, "Teleiwse o guros tou Player 2. Ksekinaei o guros tou Player 1.");
			}		
		}
		
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class DcChoiceListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) 
		{
			JButton button = (JButton) e.getSource();
			Window w = SwingUtilities.getWindowAncestor(button);
			if(button.getName().equals("choice1") && (p1.getIsFirst() || p2.getHasPlayed()))
			{			
				dc[diffdcrandoms.get(dcCounter)].buy(p1);
				p1.addDc(dc[diffdcrandoms.get(dcCounter)]);
				w.setVisible(false);
				g.updatePlayer1(p1);
			}
			else if(button.getName().equals("choice2") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				w.setVisible(false);
			}
			else if(button.getName().equals("choice1") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				dc[diffdcrandoms.get(dcCounter)].buy(p2);
				p2.addDc(dc[diffdcrandoms.get(dcCounter)]);
				w.setVisible(false);
				g.updatePlayer2(p2);
			}
			else if(button.getName().equals("choice2") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				w.setVisible(false);
			}
			
		}
		
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class MyDealCardsListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			JButton button = (JButton) e.getSource();
			if(button.getName().equals("MyDealCards1"))
			{
				JButton[] options = new JButton[20];
				for(int i = 0; i < p1.getDc().size(); i++)
				{
					if(!p1.getDc().get(i).equals(null))
					{
						options[i] = new JButton("Poula tin karta "+p1.getDc().get(i).getMessage()+" stin timi "+p1.getDc().get(i).getSellPrice());
						options[i].setName("Sell"+(i+1));
						
				     }
				}
		         JOptionPane.showOptionDialog(g,
		        		 "Kartes sthn katoxh sou: \n",
		        		 "My Deal Cards",
		         JOptionPane.OK_OPTION,
		         0,
		         null,
		         options,
		         options[0]);
			}
			else if(button.getName().equals("MyDealCards2"))
			{
				JButton[] options = new JButton[20];
				for(int i = 0; i < p2.getDc().size(); i++)
				{
					if(!p2.getDc().get(i).equals(null))
					{
						options[i] = new JButton("Poula tin karta "+p2.getDc().get(i).getMessage()+" stin timi "+p2.getDc().get(i).getSellPrice());
						options[i].setName("Sell"+(i+1));
					}
				}
		         JOptionPane.showOptionDialog(g,
		        		 "Kartes sthn katoxh sou: \n",
		        		 "My Deal Cards",
		         JOptionPane.OK_OPTION,
		         0,
		         null,
		         options,
		         options[0]);
			}
					
			
		}
		
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class SellListener implements ActionListener//8elei diaxwrismous gyrwn
	{

		@Override
		public void actionPerformed(ActionEvent e) 
		{
			JButton button = (JButton) e.getSource();
			if(button.getName().equals("Sell1"))
			{
				
			}
			
		}
		
	}
	
	/**
	 * 
	 * @author �����
	 *
	 */
	private class FootballMatchListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
			JButton button = (JButton) e.getSource();
			Window w = SwingUtilities.getWindowAncestor(button);
			if(button.getName().equals("Assos") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				sfm.setChoice("Nikh ghpedouxou");
				sfm.rollDice(p1);
				w.setVisible(false);
				g.updatePlayer1(p1);
			}
			else if(button.getName().equals("X") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				sfm.setChoice("Isopalia");
				sfm.rollDice(p1);
				w.setVisible(false);
				g.updatePlayer1(p1);
			}
			else if(button.getName().equals("Diplo") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				sfm.setChoice("Nikh filoksenoumenou");
				sfm.rollDice(p1);
				w.setVisible(false);
				g.updatePlayer1(p1);
			}
			else if(button.getName().equals("Tipota") && (p1.getIsFirst() || p2.getHasPlayed()))
			{
				w.setVisible(false);
			}
			else if(button.getName().equals("Assos") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				sfm.setChoice("Nikh ghpedouxou");
				sfm.rollDice(p2);
				w.setVisible(false);
				g.updatePlayer2(p2);
			}
			else if(button.getName().equals("X") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				sfm.setChoice("Isopalia");
				sfm.rollDice(p2);
				w.setVisible(false);
				g.updatePlayer2(p2);
			}
			else if(button.getName().equals("Diplo") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				sfm.setChoice("Nikh filoksenoumenou");
				sfm.rollDice(p2);
				w.setVisible(false);
				g.updatePlayer2(p2);
			}
			else if(button.getName().equals("Tipota") && (p2.getIsFirst() || p1.getHasPlayed()))
			{
				w.setVisible(false);
			}
			
		}
		
	}
	
}
