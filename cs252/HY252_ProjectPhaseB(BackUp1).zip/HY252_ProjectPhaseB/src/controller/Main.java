package controller;

public class Main {

	public static void main(String[] args) {
		Controller c = new Controller();
		c.mixUpMc();
		c.mixUpDc();
		c.whosFirst();
		c.startNewGame();
		c.performAction();
	}

}
