package model.card;

/**
 * Advertisement: contains everything needed for an advertisement card
 * @author Anagnostakis Manos
 * @version 1.0
 *
 */
public class Advertisement extends MailCard{
	
	/**
	 * constructor: constructs a new Adverisement instance
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */ 
	public Advertisement(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}

}
