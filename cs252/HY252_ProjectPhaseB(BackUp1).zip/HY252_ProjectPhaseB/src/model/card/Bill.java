package model.card;
import model.player.Player;

/**
 * Bill: contains everything needed about Bill card
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class Bill extends MailCard{
	
	private int payment;
	
	/**
	 * constructor: constructs a new Bill instance 
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */ 
	public Bill(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer(mutative)
	 * @param payment: the bill to be payed
	 * post-condition: sets the value of field payment
	 * to the argument value
	 */
	public void setPayment(int payment)
	{
		this.payment = payment;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field payment
	 * @return the payment
	 */
	public int getPayment()
	{
		return payment;
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a Player object
	 * post-condition: call setMC and setBills methods of player
	 * to add this to bills
	 */
	public void addBill(Player p) //metonomastike se addBill
	{
		//p.setMc(this);
		p.setBills(p.getBills()+payment);
	}

}
