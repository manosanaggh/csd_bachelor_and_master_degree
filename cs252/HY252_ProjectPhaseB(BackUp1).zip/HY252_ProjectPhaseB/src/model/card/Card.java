package model.card;

/**
 * Card: contains all the basic information about 
 * a card 
 * @author Anagnostakis Manos
 * @version 1.0
 */
public abstract class Card {
	
	private String type,message,order;
	private int amount,payment;
	
	/**
	 * constructor: constructs a new Card instance
	 * all types of Cards(MailCard,DealCard) extend this class so they first
	 * call this constructor as super
	 * @param type: the type of the card
	 * @param message: the message being displayed on it
	 * @param order: the order of the card that tells you what to do
	 * @param amount: the amount of the deck of cards
	 * post-condition: initializes all the fields of the class with
	 * the specified arguments type,message,order,amount
	 */
	public Card(String type,String message,String order,int amount)
	{
		this.type = type;
		this.message = message;
		this.order = order;
		this.amount = amount;
	}
	
	/**
	 * transformer(mutative)
	 * @param type: the type of the card
	 * post-condition: sets the type of the card as specified by
	 * the argument type
	 */
	public void setType(String type)
	{
		this.type = type;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns the value of field type
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}
	
	/**
	 * transformer(mutative)
	 * @param message: the message of the card
	 * post-condition: sets the field message as specified by
	 * the argument message
	 */
	public void setMessage(String message)
	{
		this.message = message;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns the value of field message
	 * @return the message
	 */
	public String getMessage()
	{
		return message;
	}
	
	/**
	 * transformer(mutative)
	 * @param order: the order given by the card
	 * post-condition: sets the value of field order
	 * as specified by the argument order
	 */
	public void setOrder(String order)
	{
		this.order = order;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns the value of field order
	 * @return the order
	 */
	public String getOrder()
	{
		return order;
	}
	
	/**
	 * transformer(mutative)
	 * @param amount: the amount of the cards
	 * post-condition: sets the field amount as specified
	 * by the argument
	 */
	public void setAmount(int amount)
	{
		this.amount = amount;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns the value of field amount
	 * @return the amount
	 */
	public int getAmount()
	{
		return amount;
	}
	
	public void setPayment(int payment)
	{
		this.payment = payment;
	}
	
	public int getPayment()
	{
		return payment;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return all information about a card to be displayed
	 * @return the string representation of all fields
	 */
	
	@Override
	public String toString()
	{
		return "Typos: "+type+"\nMinima: "+message+"\nOrder: "+order+"\nPli8os: "+amount;
	}
	

}
