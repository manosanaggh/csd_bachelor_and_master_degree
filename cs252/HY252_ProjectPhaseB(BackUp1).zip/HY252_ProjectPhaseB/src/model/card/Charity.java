package model.card;
import model.position.Jackpot;

/**
 * Charity: contains everything needed for Charity cards
 * @author Anagnostakis Manos
 * @version 1.0
 *
 */
public class Charity extends MailCard{
	
	private int payment; 
	
	/**
	 * constructor: constructs a new instance of charity
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */ 
	public Charity(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer(mutative)
	 * @param payment: the money to be given to Jackpot
	 * post-condition: sets the field payment to the
	 * value of the argument
	 */
	public void setPayment(int payment)
	{
		this.payment = payment;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field payment
	 * @return the payment
	 */
	public int getPayment()
	{
		return payment;
	}
	
	/**
	 * accessor(selector)
	 * @param jp: a reference to a Jackpot object
	 * post-condition: call setMoney method of jp
	 * adding the money of payment
	 */
	public void payJackpot(Jackpot jp) 
	{
		jp.setMoney(jp.getMoney()+payment);
	}

}
