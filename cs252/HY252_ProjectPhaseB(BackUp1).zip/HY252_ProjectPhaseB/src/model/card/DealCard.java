package model.card;
import model.player.Player;

/**
 * DealCard: contains all instances of Deal cards
 * @author �����
 * @version 1.0
 *
 */
public class DealCard extends Card{
	
	private int buyPrice,sellPrice;
	private String choice1,choice2;//added choice1,choice2
	

	/**
	 * constructor: constructs a DealCard instance 
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */ 
	public DealCard(String type,String message,String order,int amount) 
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer(mutative)
	 * @param buyPrice: the value of buyPrice field
	 * post-condition: sets the value of buyPrice
	 * to the specified argument
	 */
	public void setBuyPrice(int buyPrice)
	{
		this.buyPrice = buyPrice;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field buyPrice
	 * @return the buyPrice
	 */
	public int getBuyPrice()
	{
		return buyPrice;
	}
	
	/**
	 * transformer(mutative)
	 * @param sellPrice: the sell price of the card
	 * post-condition: sets the value of sellPrice 
	 * the argument
	 */
	public void setSellPrice(int sellPrice)
	{
		this.sellPrice = sellPrice;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field sellPrice
	 * @return the sellPrice
	 */
	public int getSellPrice()
	{
		return sellPrice;
	}
	
	public void setChoice1(String choice1)
	{
		this.choice1 = choice1;
	}
	
	public String getChoice1()
	{
		return choice1;
	}
	
	public void setChoice2(String choice2)
	{
		this.choice2 = choice2;
	}
	
	public String getChoice2()
	{
		return choice2;
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a Player object
	 * post-condition: call setDC method of played to add
	 * new deal card to the collection, call setMoney method of p 
	 * to decrease its money
	 */
	public void buy(Player p) 
	{
		p.setMoney(p.getMoney()-buyPrice);
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a Player object
	 * post-condition: call setDC method of played to delete
	 * a deal card of the collection, call setMoney method of p 
	 * to increase its money
	 */
	public void sell(Player p) 
	{
		p.setMoney(p.getMoney()+sellPrice);
	}
	
	public String toString()
	{
		return super.toString()+"\n���� ������: "+buyPrice+"\n���� �������: "+sellPrice+"\n";
	}


}
