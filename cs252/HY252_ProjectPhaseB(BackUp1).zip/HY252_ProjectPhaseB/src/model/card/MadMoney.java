package model.card;
import javax.swing.JOptionPane;

import model.player.Player;

/**
 * MadMoney: contains everything needed for MadMoney cards
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class MadMoney extends MailCard{
	
	private int payment; 
	
	/**
	 * constructor: contructs a new instance of MadMoney card
	 * by calling MailCard constructor
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */
	public MadMoney(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer(mutative)
	 * @param payment: the money received from the enemy player
	 * post-condition: sets the value of field receive to the
	 * argument
	 */
	public void setPayment(int payment)//receive fully changed
	{
		this.payment = payment;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns the value of field payment
	 * @return the payment
	 */
	public int getPayment()
	{
		return payment;
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a Player object
	 * post-condition: calls the setLoan method of p
	 */
	public void takeLoan(Player p) //DEN XREIAZETAI
	{
		int num = 0;
		int loan = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of loan: ", num));
		p.setLoan(p.getLoan()+loan);
	}

}
