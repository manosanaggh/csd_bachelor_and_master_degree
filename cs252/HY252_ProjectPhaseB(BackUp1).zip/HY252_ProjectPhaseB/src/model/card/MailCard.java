package model.card;

/**
 * MailCard: contains all the instances of mail cards
 * extends parent Class Card
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class MailCard extends Card{
	
    /**
     * constructor: contructs a new instance of a MailCard by passing all the arguments 
     * to the Card contructor
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
     * post-condition: to call the super constructor and by doing that to
     * create a MailCard instance
     */
	public MailCard(String type,String message,String order,int amount) 
	{
		super(type,message,order,amount);
	}


}
