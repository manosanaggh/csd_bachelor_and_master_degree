package model.card;
import model.position.Position;

/**
 * MoveToDeal_Buyer: contains everything needed about MoveToDeal_Buyer card
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class MoveToDeal_Buyer extends MailCard{
	
	/**
	 * constructor: constructs a new instance of MoveToDeal_Buyer card
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */ 
	public MoveToDeal_Buyer(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer(mutative)
	 * @param p: a reference pointing to a Position object
	 * post-condition: change the Position of p to (the next) Deal or Buyer position
	 */
	public void move(Position p) //DEN XREIAZETAI
	{
		
	}

}
