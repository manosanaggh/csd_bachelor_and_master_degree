package model.card;
import javax.swing.JOptionPane;

import model.player.Player;

/**
 * PayTheNeighbour: contains everything needed
 * for the card Pay The Neighbour
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class PayTheNeighbour extends MailCard{
	
	private int payment; 
	
	/**
	 * constructor: creates a new instance of a PayTheNeighbour card
	 * by passing arguments to the MailCard constructor
	 * @param type: the type of the card
	 * @param message: the message of the card
	 * @param order: the order given by the card
	 * @param amount: the amount of cards of this type
	 * post-condition: calls the super constructor with specified arguments
	 */
	public PayTheNeighbour(String type,String message,String order,int amount)
	{
		super(type,message,order,amount);
	}
	
	/**
	 * transformer (mutative)
	 * @param payment: the money you need to give 
	 * to the other Player
	 * post-condition: sets the value of field payment to
	 * the specified argument
	 */
	@Override
	public void setPayment(int payment)
	{
		this.payment = payment;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field payment
	 * @return the payment
	 */
	@Override
	public int getPayment()
	{
		return payment;
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference of Player
	 * post-condition: call setLoan method of the object 
	 * pointed by p
	 */
	public void takeLoan(Player p)//DEN XREIAZETAI
	{
		int num = 0;
		int loan = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of loan: ", num));
		p.setLoan(p.getLoan()+loan);
	}
	
	@Override
	public String toString()
	{
		return super.toString()+"\nPayment: "+payment;
	}

}
