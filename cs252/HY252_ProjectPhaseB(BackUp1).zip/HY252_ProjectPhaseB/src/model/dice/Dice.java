package model.dice;

/**
 * Dice: contains all information about a dice
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class Dice {
	
	private int number; 
	
	/**
	 * transformer(mutative)
	 * @param number: the random number of the dice (1,2,3,4,5,6)
	 * post-condition: sets the value of field
	 * number to the argument value
	 */
	public void setNumber(int number)
	{
		this.number = number;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the number of the dice
	 * @return the number
	 */
	public int getNumber()
	{
		return number;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns information about the Dice
	 * @return the number of the dice
	 */
	@Override
	public String toString()
	{
		return "You rolled a: "+number;
	}

}
