package model.piece;
import model.position.Position;

/**
 * Piece: contains all information about a piece
 * @author Anagnostakis Manos
 *
 */
public class Piece {
	
	private Position p;

	/**
	 * constructor: constructs a new instance of a Piece
	 * @param p: the position of the piece
	 * post-condition: initializes the position of the piece 
	 */
	public Piece(Position p)
	{
		this.p = p;
	}
	
	/**
	 * transformer(mutative)
	 * @param p: a reference to a Position object
	 * post-condition: sets the field p to the object of the 
	 * argument
	 */
	public void setPosition(Position p)
	{
		this.p = p;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the position p
	 * @return p
	 */
	public Position getPosition()
	{
		return p;
	}
}
