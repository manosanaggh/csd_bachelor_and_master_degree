package model.player;
import model.card.DealCard;
import model.dice.Dice;
import model.piece.Piece;
import model.position.*;

import java.util.ArrayList;
import java.util.Random;

/**
 * Player: constains all information about a Player instance
 * @author Anagnostakis Manos
 *
 */
public class Player {
	private final String name;//added
	private int money,bills,loan;
    //DEN XREIAZETAI mc egine deleted me ta methods tou
	private ArrayList<DealCard> dc; //egine arraylist
	private boolean isFirst,hasPlayed;//added isFirst-deleted hasFinished and its methods
	private Piece p;
	private Dice d;
	
	/**
	 * constructor: constructs a new Player instance with its charachteristics
	 * @param money: the total money of the player
	 * @param bills: the bills he has to pay
	 * @param loan: loans taken from the bank that he needs to pay
	 * @param mc: a reference to a MailCard array that holds MailCard instances, the mail cards of player(the bills) 
	 * @param dc: a reference to a DealCard array that holds DealCard instances, the deal cards of player(that he bought) 
	 * post-condition: initialize the fields: money,bills,loan,mc and dc to the specified arguments
	 */
	public Player(String name,int money, int bills, int loan,ArrayList<DealCard> dc) 
	{
		this.name = name;
		this.money = money;
		this.bills = bills;
		this.loan = loan;
		this.dc = dc;
	}
	
	/**
	 * transformer(mutative)
	 * @param d: a reference to a dice object
	 * post-condition: sets the field d to the reference of a dice object 
	 */
	public void setDice(Dice d)
	{
		this.d = d;

	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the field d
	 * @return the d
	 */
	public Dice getDice()
	{
		return d;
	}
	
	/**
	 * transformer(mutative)
	 * @param p: a reference to a dice object
	 * post-condition: sets the field p to the reference of a piece object 
	 */
	public void setPiece(Piece p)
	{
		this.p = p;
	}
	
	/**
	 * accesssor(selector)
	 * post-condition: return the field p
	 * @return the p
	 */
	public Piece getPiece()
	{
		return p;	
	}
	
	/**
	 * transformer(mutative)
	 * @param loan: the total amount of money the player owes to the bank
	 * post-condition: sets the value of field loan
	 * to the specified argument
	 */
	public void setLoan(int loan)
	{
	    this.loan = loan;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field load
	 * @return the loan
	 */
	public int getLoan()
	{
		return loan;
	}
	
	/**
	 * transformer(mutative)
	 * @param money: the money of the player
	 * post-condition: sets the value of field money
	 * to the specified argument
	 */
	public void setMoney(int money)
	{
		this.money = money;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field money
	 * @return the money
	 */
	public int getMoney()
	{
		return money;
	}
	
	/**
	 * transformer(mutative)
	 * @param dc: a reference to a DealCard array
	 * post-condition: sets the field dc to the reference of the argument
	 */
	public void addDc(DealCard dc) //changed the argument-needs preconditions-became addDc from setDc
	{
        this.dc.add(dc);
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the dc field
	 * @return the dc
	 */
	public ArrayList<DealCard> getDc()
	{
		return dc;
	}
	
	/**
	 * accessor(selector)
	 * @param bills: the bills owed by the player
	 * post-condition: sets the value of field bills
	 * to the specified argument
	 */
	public void setBills(int bills)
	{
		this.bills = bills;
	}

	/**
	 * accessor(selector)
	 * post-condition: return the value of field bills
	 * @return the bills
	 */
	public int getBills()
	{
		return bills;
	}
	
	/**
	 * transformer(mutative)
	 * @param hasPlayed: a boolean value that shows if the player has played or not
	 * post-condition: sets hasPlayed to true or false depending on the argument
	 */
	public void setHasPlayed(boolean hasPlayed)
	{
		this.hasPlayed = hasPlayed;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field hasPlayed
	 * @return the hasPlayed
	 */
	public boolean getHasPlayed()
	{
		return hasPlayed;
	}
	
	public void setIsFirst(boolean isFirst)//added
	{
		this.isFirst = isFirst;
	}
	
	public boolean getIsFirst()
	{
		return isFirst;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: call setNumber of field d to generate a number from 1 to 6
	 * to move the piece
	 */
	public void rollDice() 
	{
		Random r = new Random();
		d.setNumber(r.nextInt((6-1)+1)+1);
	}
	
	/**
	 * accessor(selector)
	 * post-condition: call setPosition of field p depending on the dice roll
	 */
	public void movePiece(Position pos) //added argument
	{
		p.setPosition(pos);
	}
	
	/**
	 * observer
	 * post-condition: return true if its the last day and the player (this) has more money that the other(p)
	 * @param p: a reference to a player object
	 * @param pos: a reference to a position object
	 * @return true if object this.money > p.money in the last day
	 */
	public boolean isWinner(Player p,Position pos,int duration)  //added param duration
	{
		if(this.money > p.money && pos instanceof PayDay && duration == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	/**
	 * observer
	 * post-condition: returns true if the the player who plays currently is (this)
	 * @param p: a reference to a player object
	 * @return true if its the turn of the player(this)
	 */
	public boolean plays(Player p)//DEN XREIAZETAI
	{
		if(p.getHasPlayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * transformer(applicative)
	 * post-condition: ends the turn of the player
	 */
	public void endTurn() //DEN XREIAZETAI
	{
		setHasPlayed(true);
	}
	
	/**
	 * accessor(selector)
	 * post-condition: returns information about the player to be displayed
	 * @return information about the player to be displayed
	 */
	@Override
	public String toString() 
	{
		return "<html><font color='white'>"+name+"<br><br>"+"Money: <font color='white'>"+money+"<br><br>"+"Bills: <font color='white'>"+bills+"<br><br>"+"Loan: <font color='white'>"+loan+"</font></html>";
	}

}
