package model.position;
import model.card.DealCard;
import model.player.Player;

/**
 * Buyer: contains all information about a Buyer position
 * @author Anagnostakis Manos
 * @version 1.0
 *
 */
public class Buyer extends Position{
	
	/**
	 * constructor: constructs a new instance of Buyer position by calling the Position constructor
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Buyer(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * transformer(mutative)
	 * @param dc: a reference to a DealCard object
	 * @param p: a reference to a Player object
	 * post-condition: calls sell method of dc passing p as an argument
	 */
	public void sell(DealCard dc,Player p) 
	{
		dc.sell(p);
	}

}
