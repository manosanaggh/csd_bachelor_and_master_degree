package model.position;

/**
 * Deal: contains all information about Deal positions
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class Deal extends Position{
	
	//deleted field ignored and its set/get methods
	//deleted keep
	
	/**
	 * constructor: constructs a new instance of Deal card
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Deal(int number,String type) 
	{
		super(number,type);
	}
}
