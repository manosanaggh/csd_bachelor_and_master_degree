package model.position;
import model.dice.Dice;
import model.player.Player;
/**
 * FamilyCasinoNight: contains all information about FamilyCasinoNight positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class FamilyCasinoNight extends Position{
	
	/**
	 * constructor: constructs an instance of FamilyCasinoNight position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public FamilyCasinoNight(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * @param jp: a reference to the Jackpot object
	 * @param p: a reference to a Player object
	 * @param d: a reference to a Dice object
	 * post-condition: depending on the dice roll call setMoney of p if won or Jackpot if lost
	 */
	public void payOrGetPayed(Jackpot jp,Player p,Dice d) 
	{
		if(d.getNumber()%2==1)
		{
			jp.setMoney(jp.getMoney()+500);
			p.setMoney(p.getMoney()-500);
		}
		else if(d.getNumber()%2==0)
		{
			p.setMoney(p.getMoney()+500);
		}
	}

}
