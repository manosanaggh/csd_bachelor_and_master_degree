package model.position;
import model.player.Player;

/**
 * Jackpot: contains all information about the Jackpot
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class Jackpot{
	
	private int money;
	
    public Jackpot(int money)//yphrxe apla diagrafthkan ta javadoc
    {
    	this.money = money;
    }
	
	/**
	 * transformer(mutative)
	 * @param money: the money holded by jackpot
	 * post-conditon: sets the money field to the argument
	 */
	public void setMoney(int money)
	{
		this.money = money;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field money
	 * @return the money
	 */
	public int getMoney()
	{
		return money;
	}
	
	/**
	 * accessor(selector)
	 * @param d: a reference to a dice object
	 * @param p: a reference to a player object
	 * post-condition: if the number of d is 6 call setMoney of this, 
	 * take all the money and call setMoney of p with that amount as the argument
	 */
	public void won(Player p) //does not need Dice d argument
	{
		if(p.getDice().getNumber() == 6)
		{
			p.setMoney(p.getMoney()+this.getMoney());
			this.setMoney(0);
		}
	}
	
	public String toString()//added
	{
		return "<html><font color='white'>Jackpot: "+money+"</font></html>";
	}

}
