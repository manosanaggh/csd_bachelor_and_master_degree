package model.position;
import model.player.Player;

/**
 * Lottery: contains all information about Lottery positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class Lottery extends Position{
	
	/**
	 * constructor: constructs a new instance of Lottery position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Lottery(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * @param p1: a reference to a player object
	 * @param p2: a reference to a player object
	 * @param num1: number of dice rolled by p1
	 * @param num2: number of dice rolled by p2
	 * post-condition: call rollDice of p1 and p2, compare the roll numbers to num1 and num2 till
	 * a right guess and call the setMoney of player that won
	 */
	public void rollDice(Player p1,Player p2,int num1,int num2)//ta num1 num2 na dinontai apo joptionpane stin klhsh tis synarthshs
	{
		//xreiazetai ena joptionpane na leei rikse to zari
		p1.rollDice();
		p2.rollDice();
		if(p1.getDice().getNumber()== num1)
		{
			p1.setMoney(p1.getMoney()+1000);
		}
		else if(p2.getDice().getNumber() == num2)
		{
			p2.setMoney(p2.getMoney()+1000);
		}
		else
		{
			rollDice(p1,p2,num1,num2);
		}
	}

}
