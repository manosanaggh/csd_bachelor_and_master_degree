package model.position;

/**
 * Mail: contains all information about Mail positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class Mail1 extends Position{
	
	//private int numToDraw;
	//private MailCard[] drawn = new MailCard[8]; //all card became mailcard-deleted ignored and its set/get methods
	//diagrafthke to oneMail kai twoMail
	//DIAGRAFTHKAN TA PANTA MONO O CONSTRUCTOR EMEINE
	
	/**
	 * constructor: constructs an instance of Mail position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Mail1(int number,String type) 
	{
		super(number,type);
	}
	

}
