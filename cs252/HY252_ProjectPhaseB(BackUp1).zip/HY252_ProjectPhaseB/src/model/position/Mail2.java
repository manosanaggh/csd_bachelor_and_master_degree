package model.position;

public class Mail2 extends Position//KAINOURIA CLASS
{
	/**
	 * constructor: constructs an instance of Mail position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Mail2(int number,String type) 
	{
		super(number,type);
	}
}
