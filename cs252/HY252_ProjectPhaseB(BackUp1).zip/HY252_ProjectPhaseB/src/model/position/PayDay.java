package model.position;
import model.player.Player;
import model.piece.Piece;
import javax.swing.JOptionPane;
/**
 * PayDay: contains all information about PayDay position
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class PayDay extends Position{
	//NEEDS TO CALL setignored of controller to empty deals cards but not here, puttoignored method deleted
	
	/**
	 * constructor: constructs a new PayDay instance
	 * @param number: the number of position depending on the day of month (here its always 31)
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public PayDay(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * post-condition: calls setMoney method of p to add money
	 */
	public void salary(Player p)  
	{
		p.setMoney(p.getMoney()+2500);
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * post-condition: call setMoney of p taking whatever money
	 * needed for bills and puts the deal cards to ignored list
	 */
	public void payBills(Player p) 
	{
		p.setMoney(p.getMoney()-p.getBills());
		
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * post-condition: calls setMoney of p taking money needed
	 * for tax, if money are not enough calls setLoan and takes a loan
	 */
	public void payTax(Player p)  
	{
		if(p.getMoney() >= p.getLoan()*0.1)
		{
			p.setMoney(p.getMoney()-(p.getLoan()*(10/100)));
		}
		else
		{
			int num = 0;
			int loan = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of loan: ", num));
			p.setLoan(loan);
		}
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * post-condition: calls setMoney of p taking money needed to pay the loan
	 * ,for money not payed pays the tax and the next month
	 */
	public void payLoan(Player p) 
	{
		if(p.getMoney()>=p.getLoan())
		{
		    p.setMoney(p.getMoney()-p.getLoan());
		}
		else
		{
			p.setMoney(p.getMoney()-(p.getLoan()*(10/100)-p.getLoan()));
		}
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a piece object
	 * @param p: a reference to a position object
	 * post-condition: sets the position of p to the initial status
	 * if it's not the last day
	 */
	public void initPiece(Piece p,Position pos,int duration) //pos is start,added duration
	{
		if(duration > 0)
		{
			p.setPosition(pos);
		}
	}

}
