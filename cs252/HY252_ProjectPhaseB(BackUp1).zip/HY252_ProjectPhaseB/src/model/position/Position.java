package model.position;
/**
 * Position: parents class of all positions, contains all common functionalities 
 * @author Anagnostakis Manos
 * @version 1.0
 */
public abstract class Position {
	
	private int number; 
	private String type; 
	
    /**
     * constructor: constructs a new Position with its number and type
     * @param number: 0-31 days for 1 month, 0-62 for 2 months...
     * @param type: the type (mail,...)
     * post-condition: constructs a new Position initializing the class fields
     * with the argument values
     */
	public Position(int number,String type) 
	{
		this.number = number;
		this.type = type;
	}
	
	/**
	 * transformer(mutative)
	 * @param number: the number of position
	 * post-condition: sets the value of field number to 
	 * the specified argument
	 */
	public void setNumber(int number)
	{
		this.number = number;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field number
	 * @return the number
	 */
	public int getNumber()
	{
		return number;
	}
	
	/**
	 * transformer(mutative)
	 * @param type: the type of the card
	 * post-condition: sets the value of field type 
	 * to the specified argument
	 */
	public void setType(String type)
	{
		this.type = type;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value of field type
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return information about the position to be displayed
	 * @return a string of the field values
	 */
	@Override
	public String toString()
	{
		return number+" "+type;
	}
	
	

}
