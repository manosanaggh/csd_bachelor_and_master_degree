package model.position;
import model.player.Player;

/**
 * RadioContect: contains all information about RadioContect positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class RadioContest extends Position{
	
	/**
	 * constructor: constructs a new RadioContect instance
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the position
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public RadioContest(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * @param p1: a reference to a Player object
	 * @param p2: a reference to a Player object
	 * post-condition: call rollDice of each player and the setMoney of the one that won
	 */
	public void rollDice(Player p1,Player p2)
	{
		//xreiazetai ena joptionpane na leei rikse to zari
		if(p1.getDice().getNumber() > p2.getDice().getNumber())
		{
			p1.setMoney(p1.getMoney()+1000);
		}
		else if(p1.getDice().getNumber() == p2.getDice().getNumber())
		{
			rollDice(p1, p2);
		}
		else
		{
			p2.setMoney(p2.getMoney()+1000);
		}
	}

}
