package model.position;

public class Start extends Position {
	public Start(int number,String type)
	{
		super(number,type);
	}

}
