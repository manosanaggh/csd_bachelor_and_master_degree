package model.position;
import model.player.Player;

/**
 * Jackpot: contains all information about the SundaysFootballMatch
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class SundaysFootballMatch {//dn xreiazetai bet gt einai panta 500
	
	private String choice;
	
	/**
	 * transformer(mutative)
	 * @param choice: the choice win of first team,draw,win of second team or skip
	 * post-condition: set the choice to the argument
	 */
	public void setChoice(String choice)
	{
		this.choice = choice;
	}
	
	/**
	 * accessor(selector)
	 * post-condition: return the value field choice
	 * @return the choice
	 */
	public String getChoice()
	{
		return choice;
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * @param d: a reference to a dice object
	 * post-condition: takes the money of bet from the player
	 * or gives him the double depending on the dice roll
	 */
	public void rollDice(Player p)//not need Dice d argument 
	{
		//edw epitrepetai aytomato riksimo zariou
		p.rollDice();
		if(choice.equals("Nikh ghpedouxou") &&(p.getDice().getNumber() == 1 || p.getDice().getNumber() == 2))
		{
			p.setMoney(p.getMoney()+(500*2));
		}
		else if(choice.equals("Isopalia") &&(p.getDice().getNumber() == 3 || p.getDice().getNumber() == 4))
		{
			p.setMoney(p.getMoney()+(500*2));
		}
		else if(choice.equals("Nikh filoksenoumenou") &&(p.getDice().getNumber() == 5 || p.getDice().getNumber() == 6))
		{
			p.setMoney(p.getMoney()+(500*2));
		}
		else
		{
			p.setMoney(p.getMoney()-500);
		}
	}

}
