package model.position;
import model.player.Player;

/**
 * Sweepstakes: contains all information about sweepstakes positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class Sweepstakes extends Position{
	
	/**
	 * constructor: constructs a new instance of Sweepstakes position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the card
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public Sweepstakes(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * post-condition: call rollDice and setMoney of p
	 * @param p: a reference to a player object
	 */
	public void rollDice(Player p) 
	{
		//xreiazetai ena joptionpane na leei rikse to zari
		p.rollDice();
		p.setMoney(p.getMoney()+(1000*p.getDice().getNumber()));
	}

}
