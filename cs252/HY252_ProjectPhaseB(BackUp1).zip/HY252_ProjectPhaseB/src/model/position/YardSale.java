package model.position;
import model.player.Player;
/**
 * Mail: contains all information about YardSale positions
 * @version 1.0
 * @author Anagnostakis Manos
 *
 */
public class YardSale extends Position{
	
	/**
	 * constructor: constructs an instance of YardSale position
	 * @param number: the number of position depending on the day of month
	 * @param type: the type of the card
	 * post-condition: call the super constructor and pass the specified arguments
	 */
	public YardSale(int number,String type) 
	{
		super(number,type);
	}
	
	/**
	 * accessor(selector)
	 * @param p: a reference to a player object
	 * @param d: a reference to a dice object
	 * post-condition: calls rollDice of p and setDC of p and depending
	 * on the d number rolled calls setMoney of p
	 */
	public void wellBought(Player p)//not need dice d  
	{
		//xreiazetai ena joptionpane na leei rikse to zari
		p.rollDice();
		p.setMoney(p.getMoney()-(100*p.getDice().getNumber()));
	}

}
