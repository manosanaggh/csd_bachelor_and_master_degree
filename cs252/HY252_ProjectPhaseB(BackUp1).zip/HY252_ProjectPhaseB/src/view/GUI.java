package view;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import model.player.Player;
import model.position.Jackpot;
import model.card.*;
/**
 *
 * @author Anagnostakis Manos
 * @version 1.0
 */
public class GUI extends JFrame//diafores me A fash: dn yphrxan tpt ektos ta buttons button1,ta panels table,p1Box,p2Box,infoBox, diagraftike to frame kai i klash egine extends sto JFrame
{
	private JButton diceButton1,dealCardsButton1,loanButton1,endTurnButton1,diceButton2,dealCardsButton2,loanButton2,endTurnButton2,mcButton,dcButton,choice1Button,choice2Button,b1,b2,b3,b4;
    private BackgroundImage bg;
    private JPanel p1BoxX,p1BOX,p2BoxX,p2BOX,cardsBOX,table;
    private JLabel p1toString,p2toString,jackpottoString,piece1,piece2;
    private JLabel[] positions,dates;//egine jlabel apo image kai allakse onoma se positions
    private static int counter = 0;
    private ArrayList <String> iconNames;
    public String[][] mailCards=new String[48][4]; //del
    public String[][] dealCards=new String[20][8]; //del

    /**
     * constructor: constructs a new window
     * post-condition: constructs a new window where the game is played, initializes window
     */
    public GUI()//diafores me A fash: kamia
    {
        javax.swing.UIManager.put("OptionPane.messageFont", new Font(Font.SANS_SERIF, Font.PLAIN, 20));
        javax.swing.UIManager.put("OptionPane.buttonFont", new Font(Font.SANS_SERIF, Font.PLAIN, 20));
        setTitle("PAYDAY");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
    	setSize(new Dimension(1800,1000));
    	setVisible(true);
    	iconNames = new ArrayList<String>();
    	positions = new JLabel[32];
    	dates = new JLabel[32];
    	for(int i = 0; i < 32; i++)
    	{
    		if(i == 0)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Start");
    		}
    		else if(i == 1 && i == 8 && i == 15 & i == 22 && i == 29)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Monday "+i);
    		}
    		else if(i == 2 && i == 9 && i == 16 & i == 23 && i == 30)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Tuesday "+i);
    		}
    		else if(i == 3 && i == 10 && i == 17 & i == 24 && i == 31)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Wednesday "+i);
    		}
    		else if(i == 4 && i == 11 && i == 18 & i == 25)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Thursday "+i);
    		}
    		else if(i == 5 && i == 12 && i == 19 & i == 26)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Friday "+i);
    		}
    		else if(i == 6 && i == 13 && i == 20 & i == 27)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Saturday "+i);
    		}
    		else if(i == 7 && i == 14 && i == 21 & i == 28)
    		{
    			dates[i] = new JLabel();
    			dates[i].setText("Sunday "+i);
    		}
    		
    	}
    	piece1 = new JLabel();
    	piece2 = new JLabel();
    	validate();
    	
    }
    
    /**
     * 
     * @param p1
     * @param p2
     * @param jp
     */
    public void initLabels(Player p1,Player p2,Jackpot jp)//diafores me A fash: dn yphrxe
    {
    	p1toString = new JLabel();
    	p1toString.setText(p1.toString());
    	GridBagConstraints gbc = new GridBagConstraints();
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 3;
    	p1BOX.add(p1toString,gbc);
    	p2toString = new JLabel();
    	p2toString.setText(p2.toString());
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 3;
    	p2BOX.add(p2toString,gbc);
    	jackpottoString = new JLabel();
    	jackpottoString.setText(jp.toString());
    	table.add(jackpottoString);
		Image image4 = new ImageIcon("images\\pawn_blue.png").getImage();
		image4 = image4.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
		piece1.setIcon(new ImageIcon(image4));
		table.add(piece1,0);
		image4 = new ImageIcon("images\\pawn_yellow.png").getImage();
		image4 = image4.getScaledInstance(100, 100, java.awt.Image.SCALE_SMOOTH);
		piece2.setIcon(new ImageIcon(image4));
		table.add(piece2,1);
    	validate();
    }
    /**
     * transformer(mutative)
     * post-condition: initializes the buttons of the game
     */
    public void initButtons()//diafores me A fash: KAMIA
    {
    	diceButton1 = new JButton("Roll Dice");
    	diceButton1.setName("Dice1");
    	dealCardsButton1 = new JButton("My Deal Cards");
    	dealCardsButton1.setName("MyDealCards1");
    	loanButton1 = new JButton("Get Loan");
    	loanButton1.setName("Loan1");
    	endTurnButton1 = new JButton("End Turn");
    	endTurnButton1.setName("EndTurn1");
    	diceButton2 = new JButton("Roll Dice");
    	diceButton2.setName("Dice2");
    	dealCardsButton2 = new JButton("My Deal Cards");
    	dealCardsButton2.setName("MyDealCards2");
    	loanButton2 = new JButton("Get Loan");
    	loanButton2.setName("Loan2");
    	endTurnButton2 = new JButton("End Turn");
    	endTurnButton2.setName("EndTurn2");
    	mcButton = new JButton();
    	mcButton.setName("Mail");
    	dcButton = new JButton();
    	dcButton.setName("Deal");
    	choice1Button = new JButton();
    	choice1Button.setName("choice1");
    	choice2Button = new JButton();
    	choice2Button.setName("choice2");
		b1 = new JButton("Niki gipedouxou");
		b1.setName("Assos");
		b2 = new JButton("Isopalia");
		b2.setName("X");
		b3 = new JButton("Niki filoksenoumenou");
		b3.setName("Diplo");
		b4 = new JButton("Cancel");
		b4.setName("Tipota");
    	GridBagConstraints gbc = new GridBagConstraints();
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 6;
    	p1BOX.add(diceButton1,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 9;
    	p1BOX.add(dealCardsButton1,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 12;
    	p1BOX.add(loanButton1,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 15;
    	p1BOX.add(endTurnButton1,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 6;
    	p2BOX.add(diceButton2,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 9;
    	p2BOX.add(dealCardsButton2,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 12;
    	p2BOX.add(loanButton2,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 15;
    	p2BOX.add(endTurnButton2,gbc);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 15;
    	cardsBOX.add(mcButton,gbc);
    	Image image = new ImageIcon("images\\mailCard.png").getImage();
    	image = image.getScaledInstance(90, 50, Image.SCALE_SMOOTH);
    	ImageIcon icon = new ImageIcon(image);
    	mcButton.setIcon(icon);
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 20;
    	cardsBOX.add(dcButton,gbc);
    	image = new ImageIcon("images\\dealCard.png").getImage();
    	image = image.getScaledInstance(90, 50, Image.SCALE_SMOOTH);
    	icon = new ImageIcon(image);
    	dcButton.setIcon(icon);
    	validate();
    }

    /**
     * transformer(mutative)
     * post-condition: initializes the panels of the game
     */
    public void initPanels()//diafores me A fash: KAMIA
    {
    	bg = new BackgroundImage(new ImageIcon("images\\bg_green.png").getImage(),1800,1000,0,0);
    	bg.setLayout(new BorderLayout());
    	add(bg,BorderLayout.CENTER);
    	table = new JPanel();
    	table.setOpaque(false);
    	p1BoxX = new JPanel();
    	p1BoxX.setOpaque(false);
    	p1BOX = new JPanel();
    	p1BOX.setOpaque(false);
    	p2BoxX = new JPanel();
    	p2BoxX.setOpaque(false);
    	p2BOX = new JPanel();
    	p2BOX.setOpaque(false);
    	cardsBOX = new JPanel();
    	cardsBOX.setOpaque(false);
    	p1BoxX.setLayout(new BorderLayout());
    	p1BOX.setLayout(new GridBagLayout());
    	p1BoxX.add(p1BOX,BorderLayout.EAST);
    	bg.add(p1BoxX,BorderLayout.NORTH);
    	p2BoxX.setLayout(new BorderLayout());
    	p2BOX.setLayout(new GridBagLayout());
    	p2BoxX.add(p2BOX,BorderLayout.EAST);
    	bg.add(p2BoxX,BorderLayout.SOUTH);
    	cardsBOX.setLayout(new GridBagLayout());
    	bg.add(cardsBOX,BorderLayout.EAST);
    	table.setLayout(new GridLayout(5,7));
    	bg.add(table, BorderLayout.WEST);
    	validate();
    }
    
    /**
     * 
     * @author �����
     *
     */
    public class BackgroundImage extends JComponent//added
    {
        private Image image;
        private int x,y;
        
        public BackgroundImage(Image image,int xsize,int ysize,int x, int y)
        {
        	this.x = x;
        	this.y = y;
        	this.image = image.getScaledInstance(xsize, ysize, Image.SCALE_SMOOTH);
        }
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(image, x, y, this);
        }
    }
    
    /**
     * 
     * @param i
     */
    public void setImages(int i)//diafores me A fash: exei to argument
    {
    	if(counter == 0)
    	{
        	Image image = new ImageIcon("images\\positionIcons\\start.png").getImage();
        	image = image.getScaledInstance(105, 105, Image.SCALE_SMOOTH);
        	positions[counter] = new JLabel(new ImageIcon(image));
        	//positions[counter].setBounds(80+i*250, 100, 100, 100);
        	//table.add(dates[counter]);//
        	table.add(positions[counter],counter);
        	//table.add(positions[counter]);
        	counter++;
    	}
    	else if(counter == 31)
    	{
        	Image image = new ImageIcon("images\\positionIcons\\pay.png").getImage();
        	image = image.getScaledInstance(105, 105, Image.SCALE_SMOOTH);
        	positions[counter] = new JLabel(new ImageIcon(image));
        	//positions[counter].setBounds(80+i*250, 100, 100, 100);
        	//table.add(dates[counter]);
        	table.add(positions[counter],counter);
        	//table.add(positions[counter]);
        	counter++;
    	}
    	else if(counter == 32)
    	{
        	Image image = new ImageIcon("images\\jackpot.png").getImage();
        	image = image.getScaledInstance(105, 105, Image.SCALE_SMOOTH);
        	table.add(new JLabel(new ImageIcon(image)),counter);
        	//table.add(new JLabel(new ImageIcon(image)));
        	counter++;
    	}
    	else  
    	{
        	Image image = new ImageIcon("images\\positionIcons\\"+iconNames.get(i)).getImage();
        	image = image.getScaledInstance(105, 105, Image.SCALE_SMOOTH);
        	positions[counter] = new JLabel(new ImageIcon(image));
        	//table.add(dates[counter]);
        	table.add(positions[counter],counter);
        	//table.add(positions[counter]);
        	counter++;
    	}
    	
    	validate();

    }
    
    /**
     * 
     * @param mc
     * @param i
     */
    public void showMailCard(MailCard mc,int i)//added
    {
        Object[] options = {mc.getOrder()};
         
         Image image = new ImageIcon("input\\images\\"+mailCards[i][5]).getImage();
         image = image.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
         JOptionPane.showOptionDialog(this,
        		 mc.getMessage(),
        		 mc.getType(),
         JOptionPane.OK_OPTION,
         0,
         new ImageIcon(image),
         options,
         options[0]);
         validate();
    }
    
    /**
     * 
     * @param dc
     * @param i
     */
    public void showDealCard(DealCard dc,int i)//added
    {
        JButton[] options = {choice1Button,choice2Button};
        choice1Button.setText(dc.getChoice1());
        choice2Button.setText(dc.getChoice2());

        Image image = new ImageIcon("input\\images\\"+dealCards[i][5]).getImage();
        image = image.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);       
        JOptionPane.showOptionDialog(this,
        		dc.getMessage()+"\nTimi Agoras: "+dc.getBuyPrice()+" Eyrw \nTimi pwlisis: "+dc.getSellPrice()+" Eyrw \n",
        		dc.getType(),
        JOptionPane.OK_OPTION,
        0,
        new ImageIcon(image),
        options,
        options[0]);
        validate();

    }
    
    /**
     * 
     * @return
     */
    public JButton getB1()//added
    {
    	return b1;
    }
    
    /**
     * 
     * @return
     */
    public JButton getB2()//added
    {
    	return b2;
    }
    
    /**
     * 
     * @return
     */
    public JButton getB3()//added
    {
    	return b3;
    }
    /**
     * 
     * @return
     */
    public JButton getB4()//added
    {
    	return b4;
    }
    
    /**
     * 
     * @return
     */
    public ArrayList<String> getIconNames()//added
    {
    	return iconNames;
    }
    
    /**
     * 
     * @return
     */
    public BackgroundImage getBg()//added
    {
    	return bg;
    }
	
    /**
     * 
     * @return
     */
	public JButton getDiceButton1()//added
	{
		return diceButton1;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getDiceButton2()//added
	{
		return diceButton2;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getMcButton()//added
	{
		return mcButton;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getDcButton()//added
	{
		return dcButton;
	}
	
	/**
	 * 
	 * @return
	 */
	public JPanel getTable()//added
	{
		return table;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getLoanButton1()//added
	{
		return loanButton1;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getLoanButton2()//added
	{
		return loanButton2;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getEndTurnButton1()//added
	{
		return endTurnButton1;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getEndTurnButton2()//added
	{
		return endTurnButton2;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getChoice1button()//added
	{
		return choice1Button;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getChoice2button()//added
	{
		return choice2Button;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getMyDealCards1Button()//added
	{
		return dealCardsButton1;
	}
	
	/**
	 * 
	 * @return
	 */
	public JButton getMyDealCards2Button()//added
	{
		return dealCardsButton2;
	}
	
	/**
	 * 
	 * @param pos
	 */
	public void updatePiece1(int pos)//added
	{
		piece1.setBounds((int) positions[pos].getBounds().getCenterX()-50, (int)  positions[pos].getBounds().getCenterY()-50, 100, 100);	
		bg.repaint();
	}
	
	/**
	 * 
	 * @param pos
	 */
	public void updatePiece2(int pos)//added
	{
		piece2.setBounds((int) positions[pos].getBounds().getCenterX()-25, (int)  positions[pos].getBounds().getCenterY()-50, 100, 100);		
		bg.repaint();
	}
	
	/**
	 * 
	 * @param p1
	 */
	public void updatePlayer1(Player p1)//added
	{
    	p1toString.setText(p1.toString());
    	GridBagConstraints gbc = new GridBagConstraints();
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 0;
    	gbc.gridy = 3;
    	p1BOX.add(p1toString,gbc);
	}
	
	/**
	 * 
	 * @param p2
	 */
	public void updatePlayer2(Player p2)//added
	{
		GridBagConstraints gbc = new GridBagConstraints();
    	p2toString.setText(p2.toString());
    	gbc.fill = GridBagConstraints.HORIZONTAL;
    	gbc.gridx = 10;
    	gbc.gridy = 3;
    	p2BOX.add(p2toString,gbc);

	}
	
	/**
	 * 
	 * @param jp
	 */
	public void updateJackpot(Jackpot jp)//added
	{
    	jackpottoString.setText(jp.toString());
    	table.add(jackpottoString);
	}
	
}
