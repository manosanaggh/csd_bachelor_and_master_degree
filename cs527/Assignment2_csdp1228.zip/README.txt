SAS:

Compile with "make mm". Creates mm executable.

Run with "./mm nprocs" where nprocs is the number of cores.

Generate NxN matrices with: "make matrix_generator" and then "make matrices" inserting the desired matrix size as input.

Source code: mm.C4

Created 2 speedup curves instead of 1 because the smallest matrix size that satisfies all numbers of cores is too big.

Created 1 speedup curve for 1,3,5 and 7 cores with N = 1050.

Created 1 speedup curve for 2,4,6 and 8 cores with N = 1152.




MPI:

Compile with "make mm". Creates mul executable.

Run with "mpirun -np N APPL", where N the number of processors and APPL the compiled program, including its full path.

Generate NxN matrices with: "make matrices" inserting the desired matrix size as input.

Source code: src/mm.c

Created 1 speedup curve for 1,2,3 and 4 cores (one processor per node) with N = 1200.

Created 1 speedup curve for 2,4,6 and 8 cores (two processors per node) with N = 1152.




Legend graph:

Because i did not have results for all numbers of cores resulting in having empty Excel cells, the curve points of the 3 of 4 graphs were not connected. Imagine the same points having a line that connects them. 

