#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "mpi.h"
#include <assert.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <getopt.h>

unsigned int N;
int **M1, **M2, **res;
int i = 0, B = 0, mynum, nprocs;
long seconds = 0, micros = 0;
struct timeval start, end;

void init_matrices(){
	int i;

        M1 = (int**)malloc(N*sizeof(int*));

        for(i = 0; i < N; i++){
                M1[i] = (int*)malloc(N*sizeof(int));
        }

        M2 = (int**)malloc(N*sizeof(int*));

        for(i = 0; i < N; i++){
                M2[i] = (int*)malloc(N*sizeof(int));
        }

        res = (int**)malloc(N*sizeof(int*));

        for(i = 0; i < N; i++){
                res[i] = (int*)malloc(N*sizeof(int));
        }
}

void init_and_read_matrices(char *filename){
        struct stat sb;
        char *file_contents;
        FILE *matrices;
        int count;

        matrices = fopen(filename, "r");

        int i,j;

        count = 0;

        stat(filename, &sb);
        file_contents = (char*)malloc(sb.st_size);
        while (fscanf(matrices, "%[^\n] ", file_contents) != EOF) {
                count++;
        }

        N = sqrt(count / 2);

	init_matrices();

        matrices = fopen(filename, "r");

        i = j = 0;

        count = 0;

        while (fscanf(matrices, "%[^\n] ", file_contents) != EOF) {
                if(count < pow(N,2)){
                        M1[i][j] = atoi(file_contents);
                        j++;
                        if(j == N){
                                j = 0;
                                i++;
                        }
                        if(count == pow(N,2) - 1){
                                i = j = 0;
                        }
                }
                else{
                        M2[i][j] = atoi(file_contents);
                        j++;
                        if(j == N){
                                j = 0;
                                i++;
                        }
                }
                count++;
        }

        fclose(matrices);
}


void first_proc(){
        int k, j = 0;

        init_and_read_matrices("src/matrices.txt");

        gettimeofday(&start, NULL);

        B = N/nprocs;
        //printf("---START OF multiply_matrices---\n\n");

        for(;i<B;i++){
                for(j=0;j<N;j++){
                        res[i][j]=0;
                        for(k=0;k<N;k++){
                                res[i][j]+=M1[i][k]*M2[k][j];
                        }
                }
        }
}

void print_matrix(){
	int i ,j;
        printf("\nResult of multiplication: \n\n");

          for(i = 0; i < N; i++){
                for(j = 0; j < N; j++){
                        printf("%d ", res[i][j]);
                }
                printf("\n");
          }
}

MPI_Status status;
main(int argc, char **argv) 
{
int  	k = 0, prev_i,
	j,t, T;
	

/* All instances call startup routine to get their instance number (mynum) 
 * We'll also return nprocs, which the main program will need in the 
 * next revision.
*/
MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &mynum);
MPI_Comm_size(MPI_COMM_WORLD, &nprocs);


if(nprocs == 1){
        //printf("nprocs = %d, mynum=%d\n\n", nprocs, mynum);

        first_proc();

        gettimeofday(&end, NULL);

        seconds = (end.tv_sec - start.tv_sec);
        micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);


        print_matrix();

        printf("\nMultiplication executed in: %d seconds and %d micros\n\n\n", seconds, micros);

}
else{
	if(mynum == 0){
		init_and_read_matrices("src/matrices.txt");

		gettimeofday(&start, NULL);

		i = 0;
		B = (N/(nprocs-1)); 
		for(t = 1; t < nprocs; t++){
        		MPI_Send(&N, 1, MPI_INT, t, 0, MPI_COMM_WORLD);
        		for(j = 0; j < N; j++){
                		MPI_Send(M1[j], N, MPI_INT, t, 0, MPI_COMM_WORLD);
                		MPI_Send(M2[j], N, MPI_INT, t, 0, MPI_COMM_WORLD);
        		}


        		MPI_Send(&i, 1, MPI_INT, t, 0, MPI_COMM_WORLD);

       			MPI_Send(&B, 1, MPI_INT, t, 0, MPI_COMM_WORLD);

			i += (N/(nprocs-1));
			B += (N/(nprocs-1));
		}

		T = N / (nprocs-1);
		j = 0;

		for(t = 1; t < nprocs; t++){
        		for(; j < T; j++){
                		MPI_Recv(res[j], N, MPI_INT, t, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        		}	
			T += (N/ (nprocs-1));
		}

        	gettimeofday(&end, NULL);
       	 	seconds = (end.tv_sec - start.tv_sec);
        	micros = ((seconds * 1000000) + end.tv_usec) - (start.tv_usec);

		print_matrix();		

		printf("\nMultiplication executed in: %d seconds and %d micros\n\n\n", seconds, micros);
	}
	else{
		MPI_Recv(&N, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);		
		init_matrices();
        for(j = 0; j < N; j++){
                MPI_Recv(M1[j], N, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                MPI_Recv(M2[j], N, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        MPI_Recv(&i, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&B, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);


	prev_i = i;

        //printf("---START OF multiply_matrices---\n\n");
        for(;i<B;i++){
                for(j=0;j<N;j++){
                        res[i][j]=0;
                        for(k=0;k<N;k++){
                                res[i][j]+=M1[i][k]*M2[k][j];
                        }
                }
        }


	i = prev_i;

        for(; i < B; i++){
                MPI_Send(res[i], N, MPI_INT, 0, 0, MPI_COMM_WORLD);
        }

	
	}
}


MPI_Finalize();
}
