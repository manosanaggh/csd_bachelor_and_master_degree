Build, compile, run info.

The src folder contains the macros with spin, ticket and mcs locks and each one is using centralized barriers. There are also the vanilla locks and barriers in c.linux.m4.

Then there are 2 more folders each one with the implementation and Makefile of the test applications.

WaterNSquared produced technical errors with compilation so it was skipped.


Compiling mm.C4:

Re-read the README file of assignment 2 to remember how to generate matrices for the input.

Use either make mm_spin, make mm_ticket or make mm_mcs to test centralized barriers. Matrix multiplication implementation uses only barriers and no locks so either one is having the same result.


Compiling lu.C4:

Use make lu_spin to compile with spin locks.

Use make lu_ticket to compile with ticket locks.

Use make lu_mcs to compile with mcs locks.

All sets of macros use centralized barriers.



Execution time and speedups:

Matrix multiply with vanilla barriers:
16.4 sec with 1 processor
8.3 sec with 2 processors

LU with vanilla locks/vanilla barriers:
0.9 sec with 1 processor
0.4 sec with 2 processors

Matrix multiply with centralized barriers:
15.9 sec with 1 processor
8.3 sec with 2 processors
speedup against vanilla with 1 processor = 0.03%
speedup against vanilla with 2 processors = 0%

LU with spin locks/centralized barriers:
1.1 sec with 1 processor
0.5 sec with 2 processors
speedup against vanilla with 1 processor = -0.18%
speedup against vanilla with 2 processors = -20%

LU with ticket locks/centralized barriers:
1.1 sec with 1 processor
0.5 sec with 2 processors
speedup against vanilla with 1 processor = -0.18%
speedup against vanilla with 2 processors = -20%

LU with mcs locks/centralized barriers:
0.9 sec with 1 processor
0.4 sec with 2 processors
speedup against vanilla with 1 processor = 0%
speedup against vanilla with 2 processors = 0%

The vanilla implementation takes almost the same execution time to run as the other implementations.

