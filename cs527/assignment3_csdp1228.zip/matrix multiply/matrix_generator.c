#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
	unsigned short i, j, n, k;

    scanf("%hu", &n);
	srand(time(NULL));;
for(k = 0; k < 2; k++){
    for(i = 0; i < n;i++) {
    	for(j = 0; j < n;j++) {
    		printf("%d\n", rand()%100);
    	}
    	//printf("\n");
    }
}

	return 0;
}
